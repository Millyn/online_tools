(() => {
  const MESSAGE_SELECTOR = ['[data-a-target="chat-line-message"]', '[data-test-selector="chat-line-message"]', ".chat-line__message"].join(",");
  const BODY_SELECTORS = ['[data-a-target="chat-message-text"]', '[data-test-selector="chat-line-message-body"]', ".text-fragment"];
  const CACHE_LIMIT = 500;
  let settings = { enabled: true, targetLanguage: "简体中文", hoverDelay: 350, subtitleSize: 22, subtitleOpacity: 0.75, subtitlePosition: null, voiceDiagnostics: false };
  let pageUrl = location.href;
  let pageContext = { channel: "", category: "" };
  let voiceState = { active: false, status: "stopped", sessionId: "" };
  let hoverTimer = null;
  let activeLine = null;
  let requestSequence = 0;
  let translatingOutgoing = false;
  const pageCache = new Map();

  initialize();

  async function initialize() {
    settings = { ...settings, ...(await chrome.storage.local.get(settings)) };
    document.addEventListener("pointerover", onPointerOver, true);
    document.addEventListener("pointerout", onPointerOut, true);
    chrome.storage.onChanged.addListener(onSettingsChanged);
    chrome.runtime.onMessage.addListener(onRuntimeMessage);
    ensureVoiceButton();
    refreshPageContext();
    ensureOutgoingButton();
    setInterval(maintenance, 1500);
    setInterval(() => {
      if (voiceState.active) chrome.runtime.sendMessage({ type: "VOICE_HEARTBEAT", sessionId: voiceState.sessionId }).catch(() => {});
    }, 5000);
  }

  function maintenance() {
    if (location.href !== pageUrl) {
      pageUrl = location.href;
      clearPageState();
      refreshPageContext(true);
    } else refreshPageContext(false);
    ensureVoiceButton();
    ensureOutgoingButton();
  }

  function onRuntimeMessage(message, sender, sendResponse) {
    if (message?.type === "TCAT_PING") { sendResponse({ twitchPage: true, ...pageContext }); return false; }
    if (message?.type === "VOICE_PAGE_STATUS") {
      voiceState = { active: Boolean(message.active), status: message.status || "stopped", sessionId: message.sessionId || "" };
      renderVoiceButton(message.detail);
      if (!voiceState.active) hideSubtitle();
      return false;
    }
    if (message?.type !== "SUBTITLE") return false;
    if (voiceState.sessionId && message.sessionId && voiceState.sessionId !== message.sessionId) return false;
    showSubtitle(message);
    return false;
  }

  function refreshPageContext(force = false) {
    const channel = channelFromPath();
    const category = readCategory();
    if (!force && channel === pageContext.channel && category === pageContext.category) return;
    pageContext = { channel, category };
    chrome.runtime.sendMessage({ type: "PAGE_CONTEXT", channel, category }).catch(() => {});
  }

  function readCategory() {
    const selectors = ['[data-a-target="stream-game-link"]', '[data-a-target="game-link"]', 'a[href*="/directory/category/"]'];
    for (const selector of selectors) {
      for (const node of document.querySelectorAll(selector)) {
        const text = normalize(node.textContent || node.getAttribute("aria-label") || "");
        if (text && text.length <= 120) return text;
      }
    }
    return "";
  }

  function channelFromPath() {
    const first = location.pathname.split("/").filter(Boolean)[0] || "";
    return new Set(["directory", "downloads", "jobs", "p", "search", "settings", "subscriptions", "videos", "wallet"]).has(first.toLowerCase()) ? "" : first;
  }

  function ensureVoiceButton() {
    if (!pageContext.channel && !channelFromPath()) return;
    if (document.querySelector("#tcat-voice-toggle")) return;
    const button = document.createElement("button");
    button.id = "tcat-voice-toggle";
    button.type = "button";
    button.addEventListener("click", toggleVoice);
    document.body.append(button);
    renderVoiceButton();
  }

  async function toggleVoice() {
    const button = document.querySelector("#tcat-voice-toggle");
    if (!button || button.disabled) return;
    button.disabled = true;
    button.textContent = voiceState.active ? "正在停止…" : "正在打开确认窗口…";
    try {
      if (!voiceState.active) {
        const opened = await chrome.runtime.sendMessage({ type: "OPEN_CAPTURE_POPUP" });
        if (!opened?.ok) throw new Error(opened?.error || "无法打开插件窗口，请点击浏览器工具栏中的插件图标");
        showVoiceNotice("请在插件窗口点击“开启当前页面字幕”", false);
        renderVoiceButton();
        return;
      }
      const response = await chrome.runtime.sendMessage({ type: "TOGGLE_PAGE_VOICE" });
      if (!response?.ok) throw new Error(response?.error || "操作失败");
      voiceState.active = Boolean(response.active);
      voiceState.sessionId = response.sessionId || "";
      voiceState.status = response.active ? "starting" : "stopped";
      renderVoiceButton();
    } catch (error) {
      const detail = error?.message || String(error);
      voiceState = { active: false, status: "error", sessionId: "" };
      renderVoiceButton(detail);
      showVoiceNotice(detail, true);
    } finally { button.disabled = false; }
  }

  function renderVoiceButton(detail = "") {
    const button = document.querySelector("#tcat-voice-toggle");
    if (!button) return;
    button.dataset.active = String(voiceState.active);
    button.dataset.status = voiceState.status;
    button.textContent = voiceState.active ? (voiceState.status === "running" ? "■ 关闭 AI 字幕" : "◌ 字幕启动中…") : "▶ 开启 AI 字幕";
    button.title = detail || (pageContext.category ? `当前分区：${pageContext.category}` : "将仅对当前直播页面捕获音频");
    if (detail && voiceState.status === "error") showVoiceNotice(detail, true);
  }

  function showVoiceNotice(text, isError = false) {
    let notice = document.querySelector("#tcat-voice-notice");
    if (!notice) { notice = document.createElement("div"); notice.id = "tcat-voice-notice"; document.body.append(notice); }
    notice.textContent = text;
    notice.classList.toggle("is-error", isError);
    notice.classList.add("is-visible");
    clearTimeout(notice.hideTimer);
    notice.hideTimer = setTimeout(() => notice.classList.remove("is-visible"), 8000);
  }

  function ensureOutgoingButton() {
    const input = findChatInput();
    if (!input || document.querySelector("#tcat-outgoing-translate")) return;
    const button = document.createElement("button");
    button.id = "tcat-outgoing-translate";
    button.type = "button";
    button.textContent = "中→EN";
    button.title = "把聊天框中的中文翻译成英文";
    // Twitch may replace its controlled editor while React is reconciling it.
    // Resolve the live editor when the click is handled instead of retaining a stale node.
    button.addEventListener("click", () => translateOutgoing(button));
    const anchor = input.closest('[data-a-target="chat-input"]') || input.parentElement;
    (anchor?.parentElement || input.parentElement)?.append(button);
  }

  function findChatInput() {
    return document.querySelector('[data-a-target="chat-input"] textarea, [data-a-target="chat-input"][contenteditable="true"], textarea[data-a-target="chat-input"], [contenteditable="true"][data-a-target="chat-input"]');
  }

  async function translateOutgoing(button) {
    if (translatingOutgoing) return;
    let input = findChatInput();
    if (!input) { flashButton(button, "未找到聊天框"); return; }
    const original = readInput(input).trim();
    if (!original) { flashButton(button, "请先输入中文"); return; }
    if (original.length > 500) { flashButton(button, "内容过长"); return; }
    translatingOutgoing = true;
    button.disabled = true;
    button.textContent = "翻译中…";
    try {
      const response = await chrome.runtime.sendMessage({ type: "TRANSLATE", context: "outgoing", text: original, category: pageContext.category });
      if (!response?.ok) throw new Error(response?.error || "翻译失败");
      const translated = String(response.translation || "").trim();
      if (!translated) throw new Error("没有返回英文译文");
      input = await writeInputStable(translated);
      if (!input) throw new Error("Twitch 输入框未接受译文，请重试");
      button.textContent = "已填入，请手动发送";
    } catch (error) {
      button.textContent = error?.message || "翻译失败";
    } finally {
      translatingOutgoing = false;
      setTimeout(() => { button.disabled = false; button.textContent = "中→EN"; }, 2600);
    }
  }

  function readInput(input) { return "value" in input ? input.value : input.innerText || input.textContent || ""; }

  async function writeInputStable(text) {
    // React/Slate can replace or reconcile Twitch's chat editor after an input
    // event. Reacquire it and require several stable observations before success.
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const input = findChatInput();
      if (!input) return null;
      if (!writeInputOnce(input, text)) return null;
      let stable = true;
      for (const wait of [40, 120, 260]) {
        await delay(wait);
        const live = findChatInput();
        if (!live || readInput(live).trim() !== text) { stable = false; break; }
      }
      if (stable) return findChatInput();
    }
    return null;
  }

  function writeInputOnce(input, text) {
    input.focus();
    if ("value" in input) {
      // The native setter is required for React's controlled value tracker.
      const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (setter) setter.call(input, text);
      else input.value = text;
      input.setSelectionRange?.(text.length, text.length);
      input.dispatchEvent(createInputEvent("input", text));
      return true;
    } else {
      const selection = getSelection();
      const range = document.createRange();
      range.selectNodeContents(input);
      selection.removeAllRanges(); selection.addRange(range);
      // For Twitch's contenteditable/Slate variant, this is the browser edit
      // operation its editor recognizes as user text insertion.
      const inserted = document.execCommand("insertText", false, text);
      // Never fall back to textContent. It only changes the visible DOM while
      // Twitch's editor state may still contain (and submit) the original text.
      if (!inserted) return false;
      const end = document.createRange();
      end.selectNodeContents(input); end.collapse(false);
      selection.removeAllRanges(); selection.addRange(end);
      return true;
    }
  }

  function createInputEvent(type, text) {
    try { return new InputEvent(type, { bubbles: true, composed: true, inputType: "insertReplacementText", data: text }); }
    catch { return new Event(type, { bubbles: true, composed: true }); }
  }
  function delay(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

  function flashButton(button, text) { button.textContent = text; setTimeout(() => { button.textContent = "中→EN"; }, 1400); }

  function showSubtitle(message) {
    let overlay = document.querySelector("#tcat-subtitle-overlay");
    if (!overlay) {
      overlay = document.createElement("div"); overlay.id = "tcat-subtitle-overlay";
      overlay.innerHTML = '<div class="tcat-subtitle-original"></div><div class="tcat-subtitle-translation"></div><div class="tcat-subtitle-diagnostics"></div>';
      overlay.title = "拖动可移动字幕；双击恢复默认位置";
      document.body.append(overlay); enableOverlayDragging(overlay); applyOverlaySettings(overlay);
    }
    overlay.classList.toggle("is-error", Boolean(message.error));
    overlay.querySelector(".tcat-subtitle-original").textContent = message.original;
    overlay.querySelector(".tcat-subtitle-translation").textContent = message.translation;
    const diagnostics = overlay.querySelector(".tcat-subtitle-diagnostics");
    const metric = message.diagnostics || {};
    diagnostics.textContent = settings.voiceDiagnostics
      ? `音频 ${formatMs(metric.audioMs)} · 排队 ${formatMs(metric.queueMs)} · 识别 ${formatMs(metric.asrMs)}${metric.translationMs ? ` · 翻译 ${formatMs(metric.translationMs)}` : ""}`
      : "";
    diagnostics.hidden = !settings.voiceDiagnostics;
    overlay.classList.add("is-visible");
    clearTimeout(overlay.hideTimer); overlay.hideTimer = setTimeout(() => overlay.classList.remove("is-visible"), 9000);
  }
  function hideSubtitle() { document.querySelector("#tcat-subtitle-overlay")?.classList.remove("is-visible"); }

  function onSettingsChanged(changes, area) { if (area !== "local") return; for (const [key, change] of Object.entries(changes)) settings[key] = change.newValue; const overlay = document.querySelector("#tcat-subtitle-overlay"); if (overlay) { applyOverlaySettings(overlay); const diagnostics=overlay.querySelector(".tcat-subtitle-diagnostics"); if(diagnostics) diagnostics.hidden=!settings.voiceDiagnostics; } }
  function applyOverlaySettings(overlay) { overlay.style.setProperty("--tcat-font-size", `${Number(settings.subtitleSize) || 22}px`); overlay.style.setProperty("--tcat-bg-opacity", String(Number(settings.subtitleOpacity) || 0.75)); const p = settings.subtitlePosition; if (p && Number.isFinite(p.left) && Number.isFinite(p.top)) { overlay.style.left = `${Math.max(8, Math.min(p.left, innerWidth - 120))}px`; overlay.style.top = `${Math.max(8, Math.min(p.top, innerHeight - 60))}px`; overlay.style.bottom = "auto"; overlay.style.transform = "none"; } else { overlay.style.left = "50%"; overlay.style.top = "auto"; overlay.style.bottom = "11vh"; overlay.style.transform = "translate(-50%, 0)"; } }
  function enableOverlayDragging(overlay) { let drag = null; overlay.addEventListener("pointerdown", (e) => { const r = overlay.getBoundingClientRect(); drag = { x: e.clientX-r.left, y:e.clientY-r.top }; overlay.setPointerCapture(e.pointerId); e.preventDefault(); }); overlay.addEventListener("pointermove", (e) => { if (!drag) return; const left=Math.max(8,Math.min(e.clientX-drag.x,innerWidth-overlay.offsetWidth-8)); const top=Math.max(8,Math.min(e.clientY-drag.y,innerHeight-overlay.offsetHeight-8)); Object.assign(overlay.style,{left:`${left}px`,top:`${top}px`,bottom:"auto",transform:"none"}); settings.subtitlePosition={left,top}; }); overlay.addEventListener("pointerup", (e) => { if (!drag) return; drag=null; overlay.releasePointerCapture(e.pointerId); chrome.storage.local.set({subtitlePosition:settings.subtitlePosition}); }); overlay.addEventListener("dblclick",()=>{settings.subtitlePosition=null;chrome.storage.local.remove("subtitlePosition");applyOverlaySettings(overlay);}); }

  function onPointerOver(event) { if (!settings.enabled) return; const line=event.target.closest?.(MESSAGE_SELECTOR); if(!line||line===activeLine||line.contains(event.relatedTarget))return; clearTimeout(hoverTimer);activeLine=line;const seq=++requestSequence;hoverTimer=setTimeout(()=>translateLine(line,seq),clamp(Number(settings.hoverDelay)||350,100,1500)); }
  function onPointerOut(event) { const line=event.target.closest?.(MESSAGE_SELECTOR);if(!line||line.contains(event.relatedTarget))return;if(line===activeLine){clearTimeout(hoverTimer);activeLine=null;requestSequence+=1;} }
  async function translateLine(line) { if(!line.isConnected||line!==activeLine)return;const text=extractMessageText(line);if(!shouldTranslate(text))return;const existing=line.querySelector(":scope > .tcat-translation");if(existing?.dataset.state==="done")return;if(pageCache.has(text)){renderTranslation(line,pageCache.get(text),"done");return;}renderTranslation(line,"正在翻译…","loading");let response;try{response=await chrome.runtime.sendMessage({type:"TRANSLATE",context:"chat",text,targetLanguage:settings.targetLanguage,category:pageContext.category});}catch(error){response={ok:false,error:error.message||"插件后台连接失败"};}if(!line.isConnected)return;if(!response?.ok){renderTranslation(line,response?.error||"翻译失败","error");return;}remember(text,response.translation);renderTranslation(line,response.translation,"done"); }
  function extractMessageText(line) { const fragments=[...line.querySelectorAll(BODY_SELECTORS.join(","))];if(fragments.length){const leaves=fragments.filter(node=>!fragments.some(other=>other!==node&&node.contains(other)));const text=leaves.map(readNodeText).join(" ");if(text.trim())return normalize(text);}const clone=line.cloneNode(true);clone.querySelectorAll(".tcat-translation, [data-a-target*=badge], [data-a-target*=username], .chat-author__display-name").forEach(node=>node.remove());return normalize(readNodeText(clone)); }
  function readNodeText(node){const clone=node.cloneNode(true);clone.querySelectorAll("img[alt]").forEach(image=>image.replaceWith(` ${image.alt} `));return clone.textContent||"";}
  function shouldTranslate(text){if(!text||text.length<2||/^https?:\/\/\S+$/i.test(text)||!/[\p{L}\p{N}]/u.test(text))return false;if(settings.targetLanguage==="简体中文"){const letters=[...text].filter(c=>/\p{L}/u.test(c));const chinese=letters.filter(c=>/\p{Script=Han}/u.test(c));if(letters.length&&chinese.length/letters.length>.7)return false;}return true;}
  function renderTranslation(line,text,state){let output=line.querySelector(":scope > .tcat-translation");if(!output){output=document.createElement("div");output.className="tcat-translation";line.append(output);}output.dataset.state=state;output.textContent=text;}
  function remember(key,value){pageCache.set(key,value);if(pageCache.size>CACHE_LIMIT)pageCache.delete(pageCache.keys().next().value);}
  function clearPageState(){pageCache.clear();clearTimeout(hoverTimer);activeLine=null;requestSequence+=1;document.querySelectorAll(".tcat-translation").forEach(node=>node.remove());}
  function normalize(text){return String(text||"").replace(/\s+/g," ").trim().slice(0,2000);}
  function clamp(value,min,max){return Math.min(max,Math.max(min,value));}
  function formatMs(value){const ms=Math.max(0,Number(value)||0);return ms>=1000?`${(ms/1000).toFixed(1)}s`:`${Math.round(ms)}ms`;}
})();
