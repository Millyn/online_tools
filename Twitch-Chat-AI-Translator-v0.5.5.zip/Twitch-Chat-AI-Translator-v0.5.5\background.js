const DEFAULT_SETTINGS = {
  enabled: true,
  apiKey: "",
  targetLanguage: "简体中文",
  hoverDelay: 350,
};

const MAX_VOICE_SESSIONS = 2;
const sessions = new Map();
const pageContexts = new Map();
const restorePromise = restoreSessions();

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  const missing = Object.fromEntries(Object.entries(DEFAULT_SETTINGS).filter(([key]) => current[key] === undefined));
  if (Object.keys(missing).length) await chrome.storage.local.set(missing);
});

chrome.tabs.onRemoved.addListener((tabId) => stopVoice(tabId, "页面已关闭，字幕资源已释放"));
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url && !isTwitchChannelUrl(changeInfo.url)) stopVoice(tabId, "已离开直播间，字幕已停止");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id ?? message?.tabId;
  if (message?.type === "PAGE_CONTEXT") {
    restorePromise.then(() => updatePageContext(tabId, message.channel, message.category));
    return false;
  }
  if (message?.type === "VOICE_HEARTBEAT") {
    const session = sessions.get(tabId);
    if (session && (!message.sessionId || session.sessionId === message.sessionId)) {
      session.lastHeartbeat = Date.now();
      chrome.runtime.sendMessage({ type: "OFFSCREEN_HEARTBEAT", tabId, sessionId: session.sessionId }).catch(() => {});
    }
    return false;
  }
  if (message?.type === "TOGGLE_PAGE_VOICE") {
    togglePageVoice(tabId).then(sendResponse).catch((error) => sendResponse({ ok: false, error: readableError(error) }));
    return true;
  }
  if (message?.type === "TOGGLE_POPUP_VOICE") {
    togglePageVoice(Number(message.tabId), { captureCurrentTab: true })
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: readableError(error) }));
    return true;
  }
  if (message?.type === "STOP_PAGE_VOICE") {
    stopVoice(Number(message.tabId ?? tabId), "字幕已手动停止").then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "STOP_ALL_VOICE") {
    Promise.all([...sessions.keys()].map((id) => stopVoice(id, "全部字幕已停止"))).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "GET_VOICE_SESSIONS") {
    sendResponse({ sessions: publicSessions(), max: MAX_VOICE_SESSIONS });
    return false;
  }
  if (message?.type === "VOICE_STATUS") {
    handleVoiceStatus(message);
    return false;
  }
  if (message?.type === "ASR_TEXT") {
    // Keep the MV3 service worker alive until this room's current translation
    // drain finishes. Fire-and-forget fetches may be terminated when Chrome
    // suspends the worker, which previously produced intermittent missing subtitles.
    handleAsrText(message.text, message.tabId, message.sessionId, message.metrics)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: readableError(error) }));
    return true;
  }
  if (message?.type !== "TRANSLATE") return false;
  const category = pageContexts.get(tabId)?.category || normalizeCategory(message.category);
  translateMessage(message.text, message.targetLanguage, message.context || "chat", category)
    .then((translation) => sendResponse({ ok: true, translation }))
    .catch((error) => sendResponse({ ok: false, error: readableError(error) }));
  return true;
});

async function togglePageVoice(tabId, { captureCurrentTab = false } = {}) {
  await restorePromise;
  if (!Number.isInteger(tabId)) throw new Error("无法识别当前 Twitch 页面");
  if (sessions.has(tabId)) {
    await stopVoice(tabId, "字幕已手动停止");
    return { ok: true, active: false };
  }
  if (sessions.size >= MAX_VOICE_SESSIONS) throw new Error(`最多同时开启 ${MAX_VOICE_SESSIONS} 个直播间字幕`);
  const settings = await chrome.storage.local.get({ apiKey: "", localModelReady: false, voiceMode: "balanced", voiceModel: "distil-small-webgpu", voiceDiagnostics: false });
  if (!settings.localModelReady) throw new Error("请先在插件设置中选择本地 Whisper 模型文件夹");
  if (!String(settings.apiKey || "").trim()) throw new Error("请先在插件设置中填写 DeepSeek API Key");
  const tab = await chrome.tabs.get(tabId);
  if (!isTwitchChannelUrl(tab.url || "")) throw new Error("请先打开 Twitch 直播页面");
  if (!captureCurrentTab) throw new Error("请手动点击 Chrome 工具栏中的插件图标，再开启当前页面字幕");
  // Calling without targetTabId uses the tab that invoked the extension action.
  // This is the reliable activeTab-authorized flow for each Twitch tab.
  const streamId = await chrome.tabCapture.getMediaStreamId();
  const sessionId = crypto.randomUUID();
  const session = {
    tabId,
    sessionId,
    channel: pageContexts.get(tabId)?.channel || channelFromUrl(tab.url),
    category: pageContexts.get(tabId)?.category || "",
    status: "starting",
    detail: "正在加载本地语音模型…",
    startedAt: Date.now(),
    lastHeartbeat: Date.now(),
    translationBusy: false,
    pendingAsrText: "",
    lastAsrText: "",
    lastAsrAt: 0,
  };
  sessions.set(tabId, session);
  await persistSessions();
  await ensureOffscreen();
  try {
    const started = await chrome.runtime.sendMessage({
      type: "OFFSCREEN_START",
      streamId,
      tabId,
      sessionId,
      voiceSettings: { voiceMode: settings.voiceMode, voiceModel: settings.voiceModel, voiceDiagnostics: settings.voiceDiagnostics },
    });
    if (!started?.ok) throw new Error(started?.error || "直播音频连接失败");
  } catch (error) {
    sessions.delete(tabId);
    await persistSessions();
    notifyTab(tabId, { type: "VOICE_PAGE_STATUS", active: false, status: "error", detail: readableError(error) });
    throw error;
  }
  notifySession(session);
  return { ok: true, active: true, sessionId };
}

async function stopVoice(tabId, detail) {
  await restorePromise;
  const session = sessions.get(tabId);
  if (!session) return;
  sessions.delete(tabId);
  await persistSessions();
  await chrome.runtime.sendMessage({ type: "OFFSCREEN_STOP", tabId, sessionId: session.sessionId }).catch(() => {});
  notifyTab(tabId, { type: "VOICE_PAGE_STATUS", active: false, status: "stopped", detail });
  broadcastSessions();
}

async function handleVoiceStatus(message) {
  await restorePromise;
  const session = sessions.get(message.tabId);
  if (!session || session.sessionId !== message.sessionId) return;
  session.status = message.status;
  session.detail = String(message.detail || "");
  if (message.status === "stopped" || message.status === "error") sessions.delete(message.tabId);
  await persistSessions();
  notifyTab(message.tabId, {
    type: "VOICE_PAGE_STATUS",
    active: sessions.has(message.tabId),
    sessionId: message.sessionId,
    status: message.status,
    detail: session.detail,
  });
  broadcastSessions();
}

function updatePageContext(tabId, channel, category) {
  if (!Number.isInteger(tabId)) return;
  const next = { channel: String(channel || ""), category: normalizeCategory(category) };
  const previous = pageContexts.get(tabId);
  pageContexts.set(tabId, next);
  const session = sessions.get(tabId);
  if (session && previous?.channel && next.channel && previous.channel !== next.channel) {
    stopVoice(tabId, "检测到直播频道已切换，请在新页面重新开启字幕");
  } else if (session) {
    session.channel = next.channel;
    session.category = next.category;
    persistSessions();
    broadcastSessions();
  }
}

async function handleAsrText(text, tabId, sessionId, metrics = {}) {
  await restorePromise;
  const session = sessions.get(tabId);
  if (!session || session.sessionId !== sessionId) return;
  const clean = String(text || "").trim();
  if (!clean) return;
  const now = Date.now();
  if (clean === session.lastAsrText && now - (session.lastAsrAt || 0) < 15000) return;
  session.lastAsrText = clean;
  session.lastAsrAt = now;
  // Keep only the newest waiting utterance. DeepSeek requests must not build an
  // unbounded per-room backlog when recognition is faster than the network.
  session.pendingAsrText = { text: clean, metrics };
  return drainTranslationQueue(tabId, sessionId);
}

async function drainTranslationQueue(tabId, sessionId) {
  const initial = sessions.get(tabId);
  if (!initial || initial.sessionId !== sessionId || initial.translationBusy) return;
  initial.translationBusy = true;
  try {
    while (true) {
      const session = sessions.get(tabId);
      if (!session || session.sessionId !== sessionId) return;
      const pending = session.pendingAsrText;
      session.pendingAsrText = null;
      if (!pending) return;
      const clean = pending.text;
      notifyTab(tabId, { type: "SUBTITLE", sessionId, original: clean, translation: "翻译中…", diagnostics: pending.metrics });
      try {
        const translationStartedAt = performance.now();
        const translation = await translateMessage(clean, null, "voice", pageContexts.get(tabId)?.category || session.category);
        const diagnostics = { ...pending.metrics, translationMs: Math.round(performance.now() - translationStartedAt) };
        const current = sessions.get(tabId);
        if (!current || current.sessionId !== sessionId) return;
        // If a newer sentence arrived, skip painting this stale translation;
        // the loop immediately starts the newest request instead.
        if (!current.pendingAsrText) notifyTab(tabId, { type: "SUBTITLE", sessionId, original: clean, translation, diagnostics });
      } catch (error) {
        const current = sessions.get(tabId);
        if (!current || current.sessionId !== sessionId) return;
        if (!current.pendingAsrText) notifyTab(tabId, { type: "SUBTITLE", sessionId, original: clean, translation: `翻译失败：${readableError(error)}`, error: true });
      }
    }
  } finally {
    const current = sessions.get(tabId);
    if (current?.sessionId === sessionId) {
      current.translationBusy = false;
      if (current.pendingAsrText) drainTranslationQueue(tabId, sessionId);
    }
  }
}

async function translateMessage(text, requestedLanguage, context, category) {
  const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const apiKey = String(settings.apiKey || "").trim();
  if (!apiKey) throw new Error("请先在插件设置中填写 DeepSeek API Key");
  if (!text || typeof text !== "string") throw new Error("没有可翻译的文字");
  const categoryLine = `当前 Twitch 直播分区：${normalizeCategory(category) || "未知分区"}。仅将分区作为用词语境，不推测主播当前操作。`;
  const targetLanguage = requestedLanguage || settings.targetLanguage;
  let instruction;
  if (context === "outgoing") {
    instruction = `你是 Twitch 聊天翻译器。把用户输入的中文翻译成自然、简洁、适合直播聊天的英文。${categoryLine}只输出英文译文，不解释，不加引号。`;
  } else {
    instruction = context === "voice"
      ? `你是 Twitch 直播字幕翻译器。输入来自英文语音识别。只根据句子本身和当前直播分区，轻度修正明显的断句、重复词和同音识别错误，再翻译成${targetLanguage}。${categoryLine}无法确定时保留原意，禁止编造内容。保留用户名、专有名词和原有语气。只输出译文，不解释，不加引号。`
      : `你是 Twitch 聊天翻译器。把用户消息翻译成${targetLanguage}。${categoryLine}保留用户名、专有名词、表情和原有语气。只输出译文，不解释，不加引号。`;
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);
  let response;
  let data;
  try {
    response = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ model: "deepseek-chat", messages: [{ role: "system", content: instruction }, { role: "user", content: text.slice(0, 2000) }], temperature: 0.2, max_tokens: 500, stream: false }),
      signal: controller.signal,
    });
    // Keep the timeout active until the response body is fully consumed. fetch()
    // resolves when headers arrive, while a stalled body could otherwise block a
    // per-room latest-only queue indefinitely.
    data = await response.json().catch((error) => {
      if (error?.name === "AbortError") throw error;
      return null;
    });
  } catch (error) {
    if (error?.name === "AbortError") throw new Error("DeepSeek 响应超时，请检查网络后重试");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
  if (!response.ok) throw new Error(`DeepSeek 请求失败：${data?.error?.message || `HTTP ${response.status}`}`);
  const translation = data?.choices?.[0]?.message?.content?.trim();
  if (!translation) throw new Error("DeepSeek 没有返回译文");
  return translation;
}

async function ensureOffscreen() {
  const url = chrome.runtime.getURL("offscreen.html");
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"], documentUrls: [url] });
  if (!contexts.length) await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["USER_MEDIA"], justification: "Capture selected Twitch tab audio for local speech recognition" });
}

function notifySession(session) {
  notifyTab(session.tabId, { type: "VOICE_PAGE_STATUS", active: true, sessionId: session.sessionId, status: session.status, detail: session.detail });
  broadcastSessions();
}
function notifyTab(tabId, message) { chrome.tabs.sendMessage(tabId, message).catch(() => {}); }
function broadcastSessions() { chrome.runtime.sendMessage({ type: "VOICE_SESSIONS_CHANGED", sessions: publicSessions(), max: MAX_VOICE_SESSIONS }).catch(() => {}); }
function publicSessions() { return [...sessions.values()].map(({ tabId, sessionId, channel, category, status, detail, startedAt }) => ({ tabId, sessionId, channel, category, status, detail, startedAt })); }
async function persistSessions() {
  await chrome.storage.session.set({ voiceSessions: publicSessions() });
}
async function restoreSessions() {
  const saved = await chrome.storage.session.get({ voiceSessions: [] });
  let liveSessions = null;
  try {
    const response = await chrome.runtime.sendMessage({ type: "OFFSCREEN_GET_SESSIONS" });
    liveSessions = new Set((response?.sessions || []).map((item) => `${item.tabId}:${item.sessionId}`));
  } catch {
    liveSessions = new Set();
  }
  for (const item of saved.voiceSessions || []) {
    if (!Number.isInteger(item?.tabId) || !item?.sessionId) continue;
    if (!liveSessions.has(`${item.tabId}:${item.sessionId}`)) continue;
    sessions.set(item.tabId, {
      ...item,
      lastHeartbeat: Date.now(),
      translationBusy: false,
      pendingAsrText: "",
      lastAsrText: "",
      lastAsrAt: 0,
    });
  }
  await persistSessions();
}
function normalizeCategory(value) { return String(value || "").replace(/\s+/g, " ").trim().slice(0, 120); }
function channelFromUrl(url) { try { return new URL(url).pathname.split("/").filter(Boolean)[0] || ""; } catch { return ""; } }
function isTwitchChannelUrl(url) { const channel = channelFromUrl(url); return String(url).startsWith("https://www.twitch.tv/") && channel && !new Set(["directory", "downloads", "jobs", "p", "search", "settings", "subscriptions", "videos", "wallet"]).has(channel.toLowerCase()); }
function readableError(error) {
  const text = String(error?.message || error || "未知错误");
  if (text.includes("active stream")) return "该页面已有音频捕获，请停止旧版插件或刷新页面后重试";
  if (text.includes("Extension has not been invoked") || text.includes("activeTab permission")) return "请切换到该 Twitch 页面，手动点击 Chrome 工具栏中的插件图标后再开启字幕";
  return text;
}
