(() => {
  const MESSAGE_SELECTOR = ['[data-a-target="chat-line-message"]', '[data-test-selector="chat-line-message"]', ".chat-line__message"].join(",");
  const BODY_SELECTORS = ['[data-a-target="chat-message-text"]', '[data-test-selector="chat-line-message-body"]', ".text-fragment"];
  const CACHE_LIMIT = 500;
  let settings = { enabled: true, targetLanguage: "简体中文", hoverDelay: 350, subtitleSize: 22, subtitleOpacity: 0.75, subtitlePositionV2: null, voiceDiagnostics: false };
  let pageUrl = location.href;
  let pageContext = { channel: "", category: "" };
  let voiceState = { active: false, status: "stopped", sessionId: "" };
  let hoverTimer = null;
  let activeLine = null;
  let requestSequence = 0;
  let translatingOutgoing = false;
  let subtitlePreview = false;
  let observedPlayer = null;
  let playerResizeObserver = null;
  const pageCache = new Map();

  initialize();

  async function initialize() {
    settings = { ...settings, ...(await chrome.storage.local.get(settings)) };
    document.addEventListener("pointerover", onPointerOver, true);
    document.addEventListener("pointerout", onPointerOut, true);
    document.addEventListener("keydown", onOutgoingHotkey, true);
    chrome.storage.onChanged.addListener(onSettingsChanged);
    chrome.runtime.onMessage.addListener(onRuntimeMessage);
    refreshPageContext();
    ensureOutgoingButton();
    setInterval(maintenance, 1500);
    setInterval(() => {
      if (voiceState.active) chrome.runtime.sendMessage({ type: "VOICE_HEARTBEAT", sessionId: voiceState.sessionId }).catch(() => {});
    }, 5000);
  }

  function maintenance() {
    if (location.href !== pageUrl) {
      pageUrl = location.href;
      clearPageState();
      refreshPageContext(true);
    } else refreshPageContext(false);
    ensureOutgoingButton();
    ensureOverlayHost();
  }

  function onRuntimeMessage(message, sender, sendResponse) {
    if (message?.type === "TCAT_PING") { sendResponse({ twitchPage: true, ...pageContext }); return false; }
    if (message?.type === "GET_SUBTITLE_PREVIEW") { sendResponse({ ok: true, active: subtitlePreview }); return false; }
    if (message?.type === "TOGGLE_SUBTITLE_PREVIEW") {
      sendResponse({ ok: true, active: toggleSubtitlePreview() });
      return false;
    }
    if (message?.type === "VOICE_PAGE_STATUS") {
      voiceState = { active: Boolean(message.active), status: message.status || "stopped", sessionId: message.sessionId || "" };
      if (!voiceState.active) hideSubtitle();
      return false;
    }
    if (message?.type !== "SUBTITLE") return false;
    if (voiceState.sessionId && message.sessionId && voiceState.sessionId !== message.sessionId) return false;
    showSubtitle(message);
    return false;
  }

  function refreshPageContext(force = false) {
    const channel = channelFromPath();
    const category = readCategory();
    if (!force && channel === pageContext.channel && category === pageContext.category) return;
    pageContext = { channel, category };
    chrome.runtime.sendMessage({ type: "PAGE_CONTEXT", channel, category }).catch(() => {});
  }

  function readCategory() {
    const selectors = ['[data-a-target="stream-game-link"]', '[data-a-target="game-link"]', 'a[href*="/directory/category/"]'];
    for (const selector of selectors) {
      for (const node of document.querySelectorAll(selector)) {
        const text = normalize(node.textContent || node.getAttribute("aria-label") || "");
        if (text && text.length <= 120) return text;
      }
    }
    return "";
  }

  function channelFromPath() {
    const first = location.pathname.split("/").filter(Boolean)[0] || "";
    return new Set(["directory", "downloads", "jobs", "p", "search", "settings", "subscriptions", "videos", "wallet"]).has(first.toLowerCase()) ? "" : first;
  }

  function toggleSubtitlePreview() {
    subtitlePreview = !subtitlePreview;
    const overlay = ensureSubtitleOverlay();
    if (!overlay) return;
    overlay.classList.toggle("is-preview", subtitlePreview);
    if (subtitlePreview) {
      if (!overlay.dataset.hasSubtitle) {
        overlay.querySelector(".tcat-subtitle-original").textContent = "字幕位置预览";
        overlay.querySelector(".tcat-subtitle-translation").textContent = "拖动此字幕框调整位置";
      }
      overlay.classList.add("is-visible");
    } else if (!overlay.dataset.hasSubtitle) {
      overlay.classList.remove("is-visible");
    }
    return subtitlePreview;
  }

  function ensureOutgoingButton() {
    const send = document.querySelector('[data-a-target="chat-send-button"]');
    if (!findChatInput() || !send?.parentElement) return;
    let button = document.querySelector("#tcat-outgoing-translate");
    if (!button) {
      button = document.createElement("button");
      button.id = "tcat-outgoing-translate";
      button.type = "button";
      button.textContent = "中→EN";
      button.title = "把聊天框中的中文翻译成英文；Shift + Alt + Enter 可翻译并发送";
      button.addEventListener("click", () => translateOutgoing(button));
    }
    if (button.parentElement !== send.parentElement || button.nextElementSibling !== send) {
      send.parentElement.insertBefore(button, send);
    }
  }

  function findChatInput() {
    return document.querySelector('[data-a-target="chat-input"] textarea, [data-a-target="chat-input"][contenteditable="true"], textarea[data-a-target="chat-input"], [contenteditable="true"][data-a-target="chat-input"]');
  }

  function onOutgoingHotkey(event) {
    if (event.key !== "Enter" || !event.shiftKey || !event.altKey || event.ctrlKey || event.metaKey) return;
    const input = findChatInput();
    if (!input || (event.target !== input && !input.contains(event.target))) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    ensureOutgoingButton();
    const button = document.querySelector("#tcat-outgoing-translate");
    if (button) translateOutgoing(button, { sendAfterTranslate: true });
  }

  async function translateOutgoing(button, { sendAfterTranslate = false } = {}) {
    if (translatingOutgoing) return;
    let input = findChatInput();
    if (!input) { flashButton(button, "未找到聊天框"); return; }
    const original = readInput(input).trim();
    if (!original) { flashButton(button, "请先输入中文"); return; }
    if (original.length > 500) { flashButton(button, "内容过长"); return; }
    translatingOutgoing = true;
    button.disabled = true;
    button.textContent = "翻译中…";
    try {
      const response = await chrome.runtime.sendMessage({ type: "TRANSLATE", context: "outgoing", text: original, category: pageContext.category });
      if (!response?.ok) throw new Error(response?.error || "翻译失败");
      const translated = String(response.translation || "").trim();
      if (!translated) throw new Error("没有返回英文译文");
      input = await writeInputStable(translated);
      if (!input) throw new Error("Twitch 输入框未接受译文，请重试");
      if (sendAfterTranslate) {
        await delay(100);
        const live = findChatInput();
        if (!live || readInput(live).trim() !== translated || !editorStateLooksSynced(live, translated)) throw new Error("发送前译文校验失败，已取消发送");
        const send = document.querySelector('[data-a-target="chat-send-button"]');
        if (!send) throw new Error("未找到 Twitch 发送按钮");
        send.click();
        button.textContent = "已翻译并发送";
      } else {
        button.textContent = "已填入，请手动发送";
      }
    } catch (error) {
      button.textContent = error?.message || "翻译失败";
    } finally {
      translatingOutgoing = false;
      setTimeout(() => { button.disabled = false; button.textContent = "中→EN"; }, 2600);
    }
  }

  function readInput(input) { return "value" in input ? input.value : input.innerText || input.textContent || ""; }

  async function writeInputStable(text) {
    // Never retry an insertion: retries previously appended the same translation
    // three times. Slate performs one model-level replacement, followed only by
    // read-only stability checks.
    const input = findChatInput();
    if (!input || !(await writeInputOnce(input, text))) return null;
    for (const wait of [60, 140, 280]) {
      await delay(wait);
      const live = findChatInput();
      if (!live || readInput(live).trim() !== text || !editorStateLooksSynced(live, text)) return null;
    }
    const live = findChatInput();
    live.blur();
    await delay(140);
    const reconciled = findChatInput();
    if (!reconciled || readInput(reconciled).trim() !== text || !editorStateLooksSynced(reconciled, text)) return null;
    reconciled.focus();
    placeCaretAtEnd(reconciled);
    return reconciled;
  }

  async function writeInputOnce(input, text) {
    input.focus();
    if ("value" in input) {
      // The native setter is required for React's controlled value tracker.
      const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (setter) setter.call(input, text);
      else input.value = text;
      input.setSelectionRange?.(text.length, text.length);
      input.dispatchEvent(createInputEvent("input", text));
      return true;
    } else {
      // Slate's native beforeinput handler explicitly flushes a DOM selection
      // into its internal selection before applying insertReplacementText. This
      // updates the message model itself instead of only repainting the DOM.
      if (!selectSlateEditorContents(input)) return false;
      await delay(20);
      if (!dispatchSlateReplacement(input, text)) return false;
      return true;
    }
  }

  function selectSlateEditorContents(input) {
    input.focus();
    const leaves = [...input.querySelectorAll('[data-slate-string="true"], [data-slate-zero-width]')];
    const textNodes = leaves
      .map((leaf) => [...leaf.childNodes].find((node) => node.nodeType === Node.TEXT_NODE))
      .filter(Boolean);
    if (!textNodes.length) return false;
    const selection = getSelection();
    const range = document.createRange();
    range.setStart(textNodes[0], 0);
    range.setEnd(textNodes.at(-1), textNodes.at(-1).data.length);
    selection.removeAllRanges();
    selection.addRange(range);
    document.dispatchEvent(new Event("selectionchange", { bubbles: true }));
    return true;
  }

  function dispatchSlateReplacement(input, text) {
    try {
      const event = new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: "insertReplacementText",
        data: text,
      });
      input.dispatchEvent(event);
      // Slate prevents the browser default after applying Editor.insertText to
      // its own model. If not prevented, do not mutate the visual DOM as fallback.
      return event.defaultPrevented;
    } catch { return false; }
  }

  function editorStateLooksSynced(input, text) {
    if ("value" in input) return input.value.trim() === text;
    if (!input.matches('[data-slate-editor="true"]')) return readInput(input).trim() === text;
    const slateText = [...input.querySelectorAll('[data-slate-string="true"]')]
      .map((node) => node.textContent || "")
      .join("")
      .trim();
    return slateText === text;
  }

  function placeCaretAtEnd(input) {
    if ("value" in input) { input.setSelectionRange?.(input.value.length, input.value.length); return; }
    const leaves = [...input.querySelectorAll('[data-slate-string="true"], [data-slate-zero-width]')];
    const last = leaves.at(-1);
    const textNode = last && [...last.childNodes].find((node) => node.nodeType === Node.TEXT_NODE);
    if (!textNode) return;
    const range = document.createRange();
    range.setStart(textNode, textNode.data.length);
    range.collapse(true);
    const selection = getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function createInputEvent(type, text) {
    try { return new InputEvent(type, { bubbles: true, composed: true, inputType: "insertReplacementText", data: text }); }
    catch { return new Event(type, { bubbles: true, composed: true }); }
  }
  function delay(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

  function flashButton(button, text) { button.textContent = text; setTimeout(() => { button.textContent = "中→EN"; }, 1400); }

  function showSubtitle(message) {
    const overlay = ensureSubtitleOverlay();
    if (!overlay) return;
    overlay.dataset.hasSubtitle = "true";
    overlay.classList.toggle("is-error", Boolean(message.error));
    overlay.querySelector(".tcat-subtitle-original").textContent = message.original;
    overlay.querySelector(".tcat-subtitle-translation").textContent = message.translation;
    const diagnostics = overlay.querySelector(".tcat-subtitle-diagnostics");
    const metric = message.diagnostics || {};
    diagnostics.textContent = settings.voiceDiagnostics
      ? `音频 ${formatMs(metric.audioMs)} · 排队 ${formatMs(metric.queueMs)} · 识别 ${formatMs(metric.asrMs)}${metric.translationMs ? ` · 翻译 ${formatMs(metric.translationMs)}` : ""}`
      : "";
    diagnostics.hidden = !settings.voiceDiagnostics;
    overlay.classList.add("is-visible");
    clearTimeout(overlay.hideTimer);
    overlay.hideTimer = setTimeout(() => {
      delete overlay.dataset.hasSubtitle;
      if (!subtitlePreview) overlay.classList.remove("is-visible");
    }, 9000);
  }
  function hideSubtitle() { const overlay=document.querySelector("#tcat-subtitle-overlay"); if(overlay&&!subtitlePreview) overlay.classList.remove("is-visible"); }

  function ensureSubtitleOverlay() {
    const host = findPlayerHost();
    if (!host) return null;
    let overlay = document.querySelector("#tcat-subtitle-overlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "tcat-subtitle-overlay";
      overlay.innerHTML = '<div class="tcat-subtitle-original"></div><div class="tcat-subtitle-translation"></div><div class="tcat-subtitle-diagnostics"></div>';
      overlay.title = "拖动可移动字幕；双击恢复默认位置";
      enableOverlayDragging(overlay);
    }
    if (overlay.parentElement !== host) host.append(overlay);
    observePlayer(host);
    applyOverlaySettings(overlay);
    return overlay;
  }

  function ensureOverlayHost() {
    const overlay = document.querySelector("#tcat-subtitle-overlay");
    if (!overlay) return;
    const host = findPlayerHost();
    if (!host) return;
    if (overlay.parentElement !== host) host.append(overlay);
    observePlayer(host);
    applyOverlaySettings(overlay);
  }

  function findPlayerHost() {
    const direct = document.querySelector('[data-a-target="video-player"], .video-player');
    if (direct) return direct;
    const video = document.querySelector("video");
    return video?.closest('[data-a-target="video-player"], .video-player') || video?.parentElement || null;
  }

  function observePlayer(host) {
    if (observedPlayer === host) return;
    playerResizeObserver?.disconnect();
    observedPlayer = host;
    if (getComputedStyle(host).position === "static") host.style.position = "relative";
    playerResizeObserver = new ResizeObserver(() => {
      const overlay = document.querySelector("#tcat-subtitle-overlay");
      if (overlay) applyOverlaySettings(overlay);
    });
    playerResizeObserver.observe(host);
  }

  function onSettingsChanged(changes, area) { if (area !== "local") return; for (const [key, change] of Object.entries(changes)) settings[key] = change.newValue; const overlay = document.querySelector("#tcat-subtitle-overlay"); if (overlay) { applyOverlaySettings(overlay); const diagnostics=overlay.querySelector(".tcat-subtitle-diagnostics"); if(diagnostics) diagnostics.hidden=!settings.voiceDiagnostics; } }
  function applyOverlaySettings(overlay) {
    overlay.style.setProperty("--tcat-font-size", `${Number(settings.subtitleSize) || 22}px`);
    overlay.style.setProperty("--tcat-bg-opacity", String(Number(settings.subtitleOpacity) || 0.75));
    const p = settings.subtitlePositionV2;
    const host = overlay.parentElement;
    const halfX = Math.min(0.45, overlay.offsetWidth / Math.max(1, host?.clientWidth || 1) / 2);
    const halfY = Math.min(0.4, overlay.offsetHeight / Math.max(1, host?.clientHeight || 1) / 2);
    const x = clamp(Number.isFinite(p?.x) ? p.x : 0.5, halfX, 1 - halfX);
    const y = clamp(Number.isFinite(p?.y) ? p.y : 0.82, halfY, 1 - halfY);
    overlay.style.left = `${x * 100}%`;
    overlay.style.top = `${y * 100}%`;
    overlay.style.bottom = "auto";
    overlay.style.transform = "translate(-50%, -50%)";
  }

  function enableOverlayDragging(overlay) {
    let drag = null;
    overlay.addEventListener("pointerdown", (event) => {
      const rect = overlay.getBoundingClientRect();
      drag = { dx: event.clientX - (rect.left + rect.width / 2), dy: event.clientY - (rect.top + rect.height / 2) };
      overlay.setPointerCapture(event.pointerId);
      overlay.classList.add("is-dragging");
      event.preventDefault();
    });
    overlay.addEventListener("pointermove", (event) => {
      if (!drag) return;
      const host = overlay.parentElement;
      const rect = host.getBoundingClientRect();
      const halfX = Math.min(0.45, overlay.offsetWidth / Math.max(1, rect.width) / 2);
      const halfY = Math.min(0.4, overlay.offsetHeight / Math.max(1, rect.height) / 2);
      const x = clamp((event.clientX - drag.dx - rect.left) / rect.width, halfX, 1 - halfX);
      const y = clamp((event.clientY - drag.dy - rect.top) / rect.height, halfY, 1 - halfY);
      settings.subtitlePositionV2 = { x, y };
      overlay.style.left = `${x * 100}%`;
      overlay.style.top = `${y * 100}%`;
    });
    overlay.addEventListener("pointerup", (event) => {
      if (!drag) return;
      drag = null;
      overlay.releasePointerCapture(event.pointerId);
      overlay.classList.remove("is-dragging");
      chrome.storage.local.set({ subtitlePositionV2: settings.subtitlePositionV2 });
    });
    overlay.addEventListener("dblclick", () => {
      settings.subtitlePositionV2 = null;
      chrome.storage.local.remove("subtitlePositionV2");
      applyOverlaySettings(overlay);
    });
  }

  function onPointerOver(event) { if (!settings.enabled) return; const line=event.target.closest?.(MESSAGE_SELECTOR); if(!line||line===activeLine||line.contains(event.relatedTarget))return; clearTimeout(hoverTimer);activeLine=line;const seq=++requestSequence;hoverTimer=setTimeout(()=>translateLine(line,seq),clamp(Number(settings.hoverDelay)||350,100,1500)); }
  function onPointerOut(event) { const line=event.target.closest?.(MESSAGE_SELECTOR);if(!line||line.contains(event.relatedTarget))return;if(line===activeLine){clearTimeout(hoverTimer);activeLine=null;requestSequence+=1;} }
  async function translateLine(line) { if(!line.isConnected||line!==activeLine)return;const text=extractMessageText(line);if(!shouldTranslate(text))return;const existing=line.querySelector(":scope > .tcat-translation");if(existing?.dataset.state==="done")return;if(pageCache.has(text)){renderTranslation(line,pageCache.get(text),"done");return;}renderTranslation(line,"正在翻译…","loading");let response;try{response=await chrome.runtime.sendMessage({type:"TRANSLATE",context:"chat",text,targetLanguage:settings.targetLanguage,category:pageContext.category});}catch(error){response={ok:false,error:error.message||"插件后台连接失败"};}if(!line.isConnected)return;if(!response?.ok){renderTranslation(line,response?.error||"翻译失败","error");return;}remember(text,response.translation);renderTranslation(line,response.translation,"done"); }
  function extractMessageText(line) { const fragments=[...line.querySelectorAll(BODY_SELECTORS.join(","))];if(fragments.length){const leaves=fragments.filter(node=>!fragments.some(other=>other!==node&&node.contains(other)));const text=leaves.map(readNodeText).join(" ");if(text.trim())return normalize(text);}const clone=line.cloneNode(true);clone.querySelectorAll(".tcat-translation, [data-a-target*=badge], [data-a-target*=username], .chat-author__display-name").forEach(node=>node.remove());return normalize(readNodeText(clone)); }
  function readNodeText(node){const clone=node.cloneNode(true);clone.querySelectorAll("img[alt]").forEach(image=>image.replaceWith(` ${image.alt} `));return clone.textContent||"";}
  function shouldTranslate(text){if(!text||text.length<2||/^https?:\/\/\S+$/i.test(text)||!/[\p{L}\p{N}]/u.test(text))return false;if(settings.targetLanguage==="简体中文"){const letters=[...text].filter(c=>/\p{L}/u.test(c));const chinese=letters.filter(c=>/\p{Script=Han}/u.test(c));if(letters.length&&chinese.length/letters.length>.7)return false;}return true;}
  function renderTranslation(line,text,state){let output=line.querySelector(":scope > .tcat-translation");if(!output){output=document.createElement("div");output.className="tcat-translation";line.append(output);}output.dataset.state=state;output.textContent=text;}
  function remember(key,value){pageCache.set(key,value);if(pageCache.size>CACHE_LIMIT)pageCache.delete(pageCache.keys().next().value);}
  function clearPageState(){pageCache.clear();clearTimeout(hoverTimer);activeLine=null;requestSequence+=1;document.querySelectorAll(".tcat-translation").forEach(node=>node.remove());}
  function normalize(text){return String(text||"").replace(/\s+/g," ").trim().slice(0,2000);}
  function clamp(value,min,max){return Math.min(max,Math.max(min,value));}
  function formatMs(value){const ms=Math.max(0,Number(value)||0);return ms>=1000?`${(ms/1000).toFixed(1)}s`:`${Math.round(ms)}ms`;}
})();
