# Twitch Chat AI Translator 0.5.5

### v0.5.5 Twitch Slate 状态修复

- 不再通过 `execCommand` 修改聊天框表面 DOM。
- 使用 Slate 原生监听的 `beforeinput / insertReplacementText` 完成一次内部状态替换。
- 手动发送与 `Shift + Alt + Enter` 快捷发送现在读取同一份英文 Slate 状态。

### v0.5.4 Chat 输入修复与快捷发送

- 移除会重复追加译文的三次写入重试，译文现在最多只写入一次。
- Slate 编辑器先删除原文并确认真实状态为空，再写入英文，避免出现“原文 + TestTestTest”。
- 在 Twitch 聊天框按 `Shift + Alt + Enter`，可翻译、严格校验英文状态后自动发送。

### v0.5.3 交互与聊天输入修复

- 移除 Twitch 频道页上的 AI 字幕和字幕位置按钮，字幕启停统一由插件窗口完成。
- 将“显示字幕框并调整位置”移动到插件窗口，开启预览后可回到播放器拖动字幕框。
- 针对 Twitch Slate 聊天编辑器同步真实文本状态，避免英文只显示在表面、实际仍发送原中文。

### v0.5.2 稳定性修复

- 频道页按钮改为识别关注/订阅操作区的 DIV + Flex 布局，不再依赖订阅按钮文字或订阅状态。
- 每个 Twitch 标签页通过手动打开插件窗口取得 Chrome 捕获授权，修复第二个标签页偶发 activeTab 权限错误。

### v0.5.1 UI 调整

- AI 字幕与字幕位置按钮移动到频道订阅按钮右侧。
- 中→EN 按钮移动到聊天发送按钮左侧。
- 字幕位置按钮可随时显示预览框并拖动调整。
- 字幕框改为播放器内部相对坐标，随播放器和窗口尺寸缩放。

## v0.5.0 语音质量升级

- RTX 4070 推荐使用本地 Distil-Whisper Small English WebGPU 模型。
- 按语音停顿形成 3–10 秒完整语句，并保留短重叠避免截断单词。
- 自动移除相邻识别片段中的重复文字。
- DeepSeek 在仅使用直播分区的前提下，轻度修正明显识别错误后翻译。
- 可选字幕诊断模式显示音频、排队、识别和翻译耗时。

一个使用 DeepSeek API 翻译 Twitch 聊天消息的 Chrome 扩展。鼠标在消息上短暂停留后，译文会显示在原文下方。

新版本支持捕获 Twitch 标签页音频，在本地运行 Whisper 语音识别，再通过 DeepSeek 翻译为中文字幕。语音模型保存在用户选择的普通磁盘文件夹中，不保存在 Chrome 缓存。

## 安装

1. 打开 Chrome，在地址栏输入 `chrome://extensions`。
2. 打开右上角的“开发者模式”。
3. 点击“加载已解压的扩展程序”，选择本项目文件夹。
4. 点击插件图标，进入设置并填写自己的 DeepSeek API Key。
5. 点击“选择文件夹并自动下载”，选择一个用于长期保存模型的本地目录。
6. 打开或刷新 Twitch 直播页面，点击“开始本地语音字幕”。
7. 将鼠标停留在聊天消息上，仍然可以使用 Chat 翻译。

推荐模型官方页面：https://huggingface.co/onnx-community/whisper-tiny.en/tree/main

## 0.3 GPU 高性能模式

- RTX 4070 等现代显卡推荐 Whisper Base English FP16（约142MB）。
- 优先使用 WebGPU；Tiny 模型保留 CPU/WASM 兼容模式。
- 低延迟、均衡、高准确三档音频分段。
- 字幕框可以拖动，双击恢复默认位置。
- 设置页可调整字幕字号与背景深浅。

## 数据与缓存

- API Key 和用户设置保存在 Chrome 扩展本地存储中。
- 翻译结果只保存在当前页面的运行内存中，最多 500 条。
- 刷新页面、关闭标签页或切换直播间后，翻译缓存会清空。
- 聊天正文会被发送至 DeepSeek API 以完成翻译。
- Twitch 音频仅在本机处理，不会上传至语音识别服务。
- 本地 Whisper 识别出的文字会发送至 DeepSeek API 进行翻译。

## 权限

- `storage`：保存 API Key 与插件设置。
- `https://www.twitch.tv/*`：读取聊天消息并显示译文。
- `https://api.deepseek.com/*`：调用 DeepSeek 翻译接口。
