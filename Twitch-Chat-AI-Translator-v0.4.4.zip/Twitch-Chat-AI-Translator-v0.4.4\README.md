# Twitch Chat AI Translator 0.2

一个使用 DeepSeek API 翻译 Twitch 聊天消息的 Chrome 扩展。鼠标在消息上短暂停留后，译文会显示在原文下方。

新版本支持捕获 Twitch 标签页音频，在本地运行 Whisper 语音识别，再通过 DeepSeek 翻译为中文字幕。语音模型保存在用户选择的普通磁盘文件夹中，不保存在 Chrome 缓存。

## 安装

1. 打开 Chrome，在地址栏输入 `chrome://extensions`。
2. 打开右上角的“开发者模式”。
3. 点击“加载已解压的扩展程序”，选择本项目文件夹。
4. 点击插件图标，进入设置并填写自己的 DeepSeek API Key。
5. 点击“选择文件夹并自动下载”，选择一个用于长期保存模型的本地目录。
6. 打开或刷新 Twitch 直播页面，点击“开始本地语音字幕”。
7. 将鼠标停留在聊天消息上，仍然可以使用 Chat 翻译。

推荐模型官方页面：https://huggingface.co/onnx-community/whisper-tiny.en/tree/main

## 0.3 GPU 高性能模式

- RTX 4070 等现代显卡推荐 Whisper Base English FP16（约142MB）。
- 优先使用 WebGPU；Tiny 模型保留 CPU/WASM 兼容模式。
- 低延迟、均衡、高准确三档音频分段。
- 字幕框可以拖动，双击恢复默认位置。
- 设置页可调整字幕字号与背景深浅。

## 数据与缓存

- API Key 和用户设置保存在 Chrome 扩展本地存储中。
- 翻译结果只保存在当前页面的运行内存中，最多 500 条。
- 刷新页面、关闭标签页或切换直播间后，翻译缓存会清空。
- 聊天正文会被发送至 DeepSeek API 以完成翻译。
- Twitch 音频仅在本机处理，不会上传至语音识别服务。
- 本地 Whisper 识别出的文字会发送至 DeepSeek API 进行翻译。

## 权限

- `storage`：保存 API Key 与插件设置。
- `https://www.twitch.tv/*`：读取聊天消息并显示译文。
- `https://api.deepseek.com/*`：调用 DeepSeek 翻译接口。
