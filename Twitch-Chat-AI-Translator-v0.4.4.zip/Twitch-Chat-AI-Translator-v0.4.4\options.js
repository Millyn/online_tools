const form = document.querySelector("#settings-form");
const enabled = document.querySelector("#enabled");
const apiKey = document.querySelector("#api-key");
const targetLanguage = document.querySelector("#target-language");
const hoverDelay = document.querySelector("#hover-delay");
const status = document.querySelector("#status");
const modelBadge = document.querySelector("#model-badge");
const modelProgress = document.querySelector("#model-progress");
const progressBar = document.querySelector("#progress-bar");
const progressText = document.querySelector("#progress-text");
const voiceModel = document.querySelector("#voice-model");
const voiceMode = document.querySelector("#voice-mode");
const subtitleSize = document.querySelector("#subtitle-size");
const subtitleOpacity = document.querySelector("#subtitle-opacity");

const MODEL_PROFILES = {
  "base-webgpu": {
    repo: "onnx-community/whisper-base.en",
    name: "Whisper Base English FP32 + Q4 · WebGPU",
    files: ["config.json", "generation_config.json", "tokenizer.json", "tokenizer_config.json",
      "preprocessor_config.json", "onnx/encoder_model.onnx", "onnx/decoder_model_merged_q4.onnx"],
  },
  "tiny-fp32": {
    repo: "onnx-community/whisper-tiny.en",
    name: "Whisper Tiny English FP32 · CPU",
    files: ["config.json", "generation_config.json", "tokenizer.json", "tokenizer_config.json",
      "preprocessor_config.json", "onnx/encoder_model.onnx", "onnx/decoder_model_merged.onnx"],
  },
};

loadSettings();
refreshModelStatus();

async function loadSettings() {
  const saved = await chrome.storage.local.get({
    enabled: true,
    apiKey: "",
    targetLanguage: "简体中文",
    hoverDelay: 350,
    voiceModel: "base-webgpu",
    voiceMode: "balanced",
    subtitleSize: 22,
    subtitleOpacity: 0.75,
  });
  if (!MODEL_PROFILES[saved.voiceModel]) {
    saved.voiceModel = "base-webgpu";
    saved.localModelReady = false;
    await chrome.storage.local.set({ voiceModel: saved.voiceModel, localModelReady: false });
  }
  enabled.checked = saved.enabled;
  apiKey.value = saved.apiKey;
  targetLanguage.value = saved.targetLanguage;
  hoverDelay.value = String(saved.hoverDelay);
  voiceModel.value = saved.voiceModel;
  voiceMode.value = saved.voiceMode;
  subtitleSize.value = String(saved.subtitleSize);
  subtitleOpacity.value = String(saved.subtitleOpacity);
}

document.querySelector("#download-model").addEventListener("click", async (event) => {
  const button = event.currentTarget;
  if (!window.showDirectoryPicker) return showStatus("当前 Chrome 不支持选择本地模型目录", true);
  button.disabled = true;
  try {
    const directory = await showDirectoryPicker({ mode: "readwrite", id: "tcat-whisper-model" });
    await saveModelDirectory(directory);
    await chrome.storage.local.set({ localModelReady: false });
    const profile = MODEL_PROFILES[voiceModel.value];
    modelProgress.hidden = false;
    let completed = 0;
    for (const path of profile.files) {
      progressText.textContent = `正在下载 ${path}（${completed + 1}/${profile.files.length}）`;
      await downloadFileToDirectory(directory, profile.repo, path, (bytes) => {
        progressText.textContent = `正在下载 ${path} · ${(bytes / 1024 / 1024).toFixed(1)} MB`;
      });
      completed += 1;
      progressBar.style.width = `${Math.round(completed / profile.files.length * 100)}%`;
    }
    await chrome.storage.local.set({ localModelReady: true, localModelName: profile.name, localModelProfile: voiceModel.value, voiceModel: voiceModel.value });
    showStatus("本地模型下载完成");
    await refreshModelStatus();
  } catch (error) {
    if (error.name !== "AbortError") showStatus(`模型下载失败：${error.message}`, true);
  } finally {
    button.disabled = false;
  }
});

document.querySelector("#select-model").addEventListener("click", async (event) => {
  const button = event.currentTarget;
  button.disabled = true;
  try {
    const directory = await showDirectoryPicker({ mode: "read", id: "tcat-whisper-model" });
    const profile = MODEL_PROFILES[voiceModel.value];
    const missing = await findMissingModelFiles(directory, profile.files);
    if (missing.length) throw new Error(`缺少文件：${missing[0]}`);
    await saveModelDirectory(directory);
    await chrome.storage.local.set({ localModelReady: true, localModelName: profile.name, localModelProfile: voiceModel.value, voiceModel: voiceModel.value });
    showStatus("模型文件夹验证成功");
    await refreshModelStatus();
  } catch (error) {
    if (error.name !== "AbortError") showStatus(`无法使用该文件夹：${error.message}`, true);
  } finally {
    button.disabled = false;
  }
});

async function refreshModelStatus() {
  try {
    const directory = await getModelDirectory();
    if (!directory) return setModelBadge("未配置", false);
    const permission = await directory.queryPermission({ mode: "read" });
    if (permission === "prompt") return setModelBadge("需要重新授权", false);
    const saved = await chrome.storage.local.get({ voiceModel: "base-webgpu" });
    const profile = MODEL_PROFILES[saved.voiceModel] || MODEL_PROFILES["base-webgpu"];
    const missing = await findMissingModelFiles(directory, profile.files);
    setModelBadge(missing.length ? "文件不完整" : "模型可用", !missing.length);
  } catch {
    setModelBadge("需要重新选择", false);
  }
}

function setModelBadge(text, ready) {
  modelBadge.textContent = text;
  modelBadge.classList.toggle("ready", ready);
}

async function downloadFileToDirectory(root, repo, path, onProgress) {
  const parts = path.split("/");
  let directory = root;
  for (const part of parts.slice(0, -1)) directory = await directory.getDirectoryHandle(part, { create: true });
  const handle = await directory.getFileHandle(parts.at(-1), { create: true });
  const writable = await handle.createWritable();
  const url = `https://huggingface.co/${repo}/resolve/main/${path}?download=true`;
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok || !response.body) {
    await writable.abort();
    throw new Error(`${path} 下载失败（HTTP ${response.status}）`);
  }
  const reader = response.body.getReader();
  let received = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      await writable.write(value);
      received += value.byteLength;
      onProgress(received);
    }
    await writable.close();
  } catch (error) {
    await writable.abort();
    throw error;
  }
}

async function findMissingModelFiles(root, files = MODEL_PROFILES[voiceModel.value].files) {
  const missing = [];
  for (const path of files) {
    try { await getFileByPath(root, path); } catch { missing.push(path); }
  }
  return missing;
}

async function getFileByPath(root, path) {
  const parts = path.split("/");
  let directory = root;
  for (const part of parts.slice(0, -1)) directory = await directory.getDirectoryHandle(part);
  return (await directory.getFileHandle(parts.at(-1))).getFile();
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  await saveSettings();
  showStatus("设置已保存");
});

document.querySelector("#toggle-key").addEventListener("click", (event) => {
  const reveal = apiKey.type === "password";
  apiKey.type = reveal ? "text" : "password";
  event.currentTarget.textContent = reveal ? "隐藏" : "显示";
});

document.querySelector("#test-api").addEventListener("click", async (event) => {
  const button = event.currentTarget;
  button.disabled = true;
  showStatus("正在连接 DeepSeek…");
  try {
    await saveSettings();
    const response = await chrome.runtime.sendMessage({
      type: "TRANSLATE",
      text: "Hello, welcome to the stream!",
      targetLanguage: targetLanguage.value,
    });
    if (!response?.ok) throw new Error(response?.error || "测试失败");
    showStatus(`连接成功：${response.translation}`);
  } catch (error) {
    showStatus(error.message, true);
  } finally {
    button.disabled = false;
  }
});

async function saveSettings() {
  const modelState = await chrome.storage.local.get({ localModelProfile: "tiny-fp32" });
  await chrome.storage.local.set({
    enabled: enabled.checked,
    apiKey: apiKey.value.trim(),
    targetLanguage: targetLanguage.value,
    hoverDelay: Number(hoverDelay.value),
    voiceModel: voiceModel.value,
    voiceMode: voiceMode.value,
    subtitleSize: Number(subtitleSize.value),
    subtitleOpacity: Number(subtitleOpacity.value),
    localModelReady: modelState.localModelProfile === voiceModel.value,
  });
}

let statusTimer;
function showStatus(message, isError = false) {
  clearTimeout(statusTimer);
  status.textContent = message;
  status.classList.toggle("error", isError);
  statusTimer = setTimeout(() => { status.textContent = ""; }, 6000);
}
