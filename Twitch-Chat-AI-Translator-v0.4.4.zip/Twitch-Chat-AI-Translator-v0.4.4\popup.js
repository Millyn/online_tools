const toggle = document.querySelector("#enabled");
const state = document.querySelector("#state");
const list = document.querySelector("#sessions");
const stopAll = document.querySelector("#stop-all");
const currentVoice = document.querySelector("#current-voice");
let activeTabId = null;
let latestSessions = [];

chrome.storage.local.get({ enabled: true, apiKey: "" }).then((settings) => {
  toggle.checked = settings.enabled;
  state.textContent = settings.apiKey ? "DeepSeek 已配置" : "需要配置 API Key";
});
toggle.addEventListener("change", async () => { await chrome.storage.local.set({ enabled: toggle.checked }); state.textContent = toggle.checked ? "悬停翻译已启用" : "悬停翻译已暂停"; });
document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
stopAll.addEventListener("click", async () => { stopAll.disabled = true; await chrome.runtime.sendMessage({ type: "STOP_ALL_VOICE" }); await refresh(); stopAll.disabled = false; });
currentVoice.addEventListener("click", async () => {
  currentVoice.disabled = true;
  currentVoice.textContent = latestSessions.some((item) => item.tabId === activeTabId) ? "正在停止…" : "正在连接音频…";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTabId = tab?.id ?? activeTabId;
    if (!activeTabId || !String(tab?.url || "").startsWith("https://www.twitch.tv/")) throw new Error("请先切换到 Twitch 直播页面");
    const response = await chrome.runtime.sendMessage({ type: "TOGGLE_PAGE_VOICE", tabId: activeTabId });
    if (!response?.ok) throw new Error(response?.error || "字幕启动失败");
    await refresh();
  } catch (error) {
    state.textContent = error?.message || String(error);
  } finally { currentVoice.disabled = false; renderCurrentButton(); }
});
chrome.runtime.onMessage.addListener((message) => { if (message?.type === "VOICE_SESSIONS_CHANGED") render(message.sessions, message.max); });

async function refresh() { const result = await chrome.runtime.sendMessage({ type: "GET_VOICE_SESSIONS" }); render(result?.sessions || [], result?.max || 2); }
function render(sessions, max) {
  latestSessions = sessions;
  list.replaceChildren();
  if (!sessions.length) { const empty=document.createElement("div");empty.className="empty";empty.textContent="没有正在运行的语音字幕";list.append(empty); }
  for (const session of sessions) {
    const row=document.createElement("div");row.className="session";
    const info=document.createElement("div");const name=document.createElement("strong");name.textContent=session.channel||`标签页 ${session.tabId}`;const detail=document.createElement("small");detail.textContent=`${session.category||"未知分区"} · ${session.status==="running"?"运行中":"启动中"}`;info.append(name,detail);
    const stop=document.createElement("button");stop.textContent="停止";stop.addEventListener("click",async()=>{stop.disabled=true;await chrome.runtime.sendMessage({type:"STOP_PAGE_VOICE",tabId:session.tabId});await refresh();});
    row.append(info,stop);list.append(row);
  }
  stopAll.hidden=sessions.length<2;
  state.textContent=sessions.length?`语音字幕 ${sessions.length}/${max}`:state.textContent;
  renderCurrentButton();
}
function renderCurrentButton() {
  const active = latestSessions.some((item) => item.tabId === activeTabId);
  currentVoice.textContent = active ? "停止当前页面字幕" : "开启当前页面字幕";
  currentVoice.classList.toggle("danger", active);
}
chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => { activeTabId = tab?.id || null; renderCurrentButton(); });
refresh();
