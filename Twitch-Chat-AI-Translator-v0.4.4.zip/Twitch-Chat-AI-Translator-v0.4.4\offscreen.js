const sessions = new Map();
let asrWorker = null;
let modelState = "idle";
let loadedModel = "";
let activeJob = null;
let lastDispatchedTabId = null;
let jobWatchdog = null;
const HEARTBEAT_TIMEOUT_MS = 90000;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "OFFSCREEN_START") {
    startCapture(message)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === "OFFSCREEN_STOP") stopCapture(message.tabId, message.sessionId, false);
  if (message?.type === "OFFSCREEN_GET_SESSIONS") {
    sendResponse({ sessions: [...sessions.values()].map(({ tabId, sessionId }) => ({ tabId, sessionId })) });
    return false;
  }
  if (message?.type === "OFFSCREEN_HEARTBEAT") {
    const session = sessions.get(message.tabId);
    if (session?.sessionId === message.sessionId) session.lastHeartbeat = Date.now();
  }
});

setInterval(() => {
  const now = Date.now();
  for (const session of sessions.values()) {
    // Chrome throttles timers in background tabs (often to roughly once per
    // minute). A 20-second timeout incorrectly killed the second selected room.
    if (now - session.lastHeartbeat > HEARTBEAT_TIMEOUT_MS) stopCapture(session.tabId, session.sessionId, true, "页面连接已断开，字幕资源已释放");
    else if (session.audioContext?.state === "suspended") session.audioContext.resume().catch(() => {});
  }
}, 5000);

async function startCapture({ streamId, tabId, sessionId, voiceSettings = {} }) {
  if (!streamId || !Number.isInteger(tabId) || !sessionId) return;
  await stopCapture(tabId, null, false);
  const session = {
    tabId, sessionId, mediaStream: null, audioContext: null, processor: null, sourceNode: null,
    audioParts: [], sampleCount: 0, pendingAudio: null, lastHeartbeat: Date.now(), consecutiveErrors: 0,
    segmentSeconds: ({ fast: 2.5, balanced: 3.5, accurate: 5 })[voiceSettings.voiceMode] || 3.5,
  };
  sessions.set(tabId, session);
  sendStatus(session, "starting", "正在连接直播音频…");
  try {
    session.mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } }, video: false,
    });
    session.mediaStream.getTracks().forEach((track) => { track.onended = () => stopCapture(tabId, sessionId, true, "直播音频已结束，字幕资源已释放"); });
    session.audioContext = new AudioContext({ latencyHint: "interactive" });
    await session.audioContext.resume().catch(() => {});
    session.sourceNode = session.audioContext.createMediaStreamSource(session.mediaStream);
    session.sourceNode.connect(session.audioContext.destination);
    session.processor = session.audioContext.createScriptProcessor(4096, 1, 1);
    session.sourceNode.connect(session.processor);
    session.processor.connect(session.audioContext.destination);
    session.processor.onaudioprocess = (event) => collectAudio(session, event);
    await ensureWorker(voiceSettings.voiceModel || "base-webgpu");
    if (modelState === "ready") sendStatus(session, "running", "本地字幕运行中 · WebGPU");
    else sendStatus(session, "starting", "正在加载本地语音模型…");
  } catch (error) {
    await stopCapture(tabId, sessionId, false);
    sendStatus(session, "error", error?.message || "无法获取标签页音频");
    throw error;
  }
}

async function ensureWorker(model) {
  if (asrWorker) {
    if (loadedModel !== model) throw new Error("已有字幕正在使用另一种语音模型，请先停止后再切换模型");
    return;
  }
  loadedModel = model;
  modelState = "loading";
  asrWorker = new Worker(chrome.runtime.getURL("assets/asr-worker.js"), { type: "module" });
  asrWorker.onmessage = onWorkerMessage;
  asrWorker.onerror = (event) => {
    modelState = "failed";
    for (const session of [...sessions.values()]) {
      sendStatus(session, "error", `模型运行失败：${event.message}`);
      stopCapture(session.tabId, session.sessionId, false);
    }
  };
  asrWorker.postMessage({ type: "LOAD_MODEL", wasmBase: chrome.runtime.getURL("assets/"), model });
}

function collectAudio(session, event) {
  if (sessions.get(session.tabId)?.sessionId !== session.sessionId) return;
  const data = new Float32Array(event.inputBuffer.getChannelData(0));
  session.audioParts.push(data);
  session.sampleCount += data.length;
  if (session.sampleCount < session.audioContext.sampleRate * session.segmentSeconds) return;
  const merged = mergeAudio(session.audioParts, session.sampleCount);
  session.audioParts = [];
  session.sampleCount = 0;
  let energy = 0;
  let peak = 0;
  for (const value of merged) {
    energy += value * value;
    peak = Math.max(peak, Math.abs(value));
  }
  const rms = Math.sqrt(energy / merged.length);
  // The old RMS-only 0.008 gate discarded quiet speech (common when a Twitch
  // channel's mixer is low). Combining RMS and peak still avoids true silence
  // without suppressing a softly spoken segment.
  if (rms < 0.003 && peak < 0.015) return;
  session.pendingAudio = resample(merged, session.audioContext.sampleRate, 16000);
  pumpQueue();
}

function pumpQueue() {
  if (modelState !== "ready" || activeJob || !asrWorker) return;
  const available = [...sessions.values()].filter((item) => item.pendingAudio);
  if (!available.length) return;
  // Round-robin dispatch prevents the first opened room from monopolising the
  // shared Whisper model when two rooms continuously produce audio.
  const previousIndex = available.findIndex((item) => item.tabId === lastDispatchedTabId);
  const session = available[(previousIndex + 1) % available.length];
  if (!session) return;
  const audio = session.pendingAudio;
  session.pendingAudio = null;
  activeJob = { tabId: session.tabId, sessionId: session.sessionId };
  lastDispatchedTabId = session.tabId;
  asrWorker.postMessage({ type: "TRANSCRIBE", audio, ...activeJob }, [audio.buffer]);
  clearTimeout(jobWatchdog);
  const dispatchedJob = { ...activeJob };
  jobWatchdog = setTimeout(() => recoverStalledWorker(dispatchedJob), 60000);
}

function onWorkerMessage(event) {
  const message = event.data || {};
  if (message.type === "READY") {
    modelState = "ready";
    for (const session of sessions.values()) sendStatus(session, "running", `本地字幕运行中 · ${message.backend}`);
    pumpQueue();
    return;
  }
  if (message.type === "RESULT") {
    const session = sessions.get(message.tabId);
    if (session?.sessionId === message.sessionId && message.text) {
      session.consecutiveErrors = 0;
      chrome.runtime.sendMessage({ type: "ASR_TEXT", text: message.text, tabId: message.tabId, sessionId: message.sessionId }).catch(() => {});
    }
  }
  if (message.type === "ERROR") {
    console.error("Local Whisper worker error", message.error, message.stack || "");
    if (message.operation === "model-load") {
      modelState = "failed";
      for (const session of [...sessions.values()]) {
        sendStatus(session, "error", message.error);
        stopCapture(session.tabId, session.sessionId, false);
      }
    } else {
      const session = sessions.get(message.tabId);
      if (session?.sessionId === message.sessionId) {
        session.consecutiveErrors += 1;
        if (session.consecutiveErrors >= 3) {
          sendStatus(session, "error", `语音识别连续失败：${message.error}`);
          stopCapture(session.tabId, session.sessionId, false);
        } else {
          sendStatus(session, "running", "本地字幕运行中 · 正在跳过一段识别失败的音频");
        }
      }
    }
  }
  if ((message.type === "RESULT" || message.type === "ERROR") && activeJob && message.tabId === activeJob.tabId && message.sessionId === activeJob.sessionId) {
    clearTimeout(jobWatchdog);
    jobWatchdog = null;
    activeJob = null;
    pumpQueue();
  }
}

function recoverStalledWorker(job) {
  if (!activeJob || activeJob.tabId !== job?.tabId || activeJob.sessionId !== job?.sessionId) return;
  const affected = sessions.get(job.tabId);
  if (affected?.sessionId === job.sessionId) {
    sendStatus(affected, "starting", "语音识别响应超时，正在重新加载模型…");
  }
  asrWorker?.terminate();
  asrWorker = null;
  activeJob = null;
  jobWatchdog = null;
  modelState = "idle";
  const model = loadedModel;
  loadedModel = "";
  if (!sessions.size) return;
  ensureWorker(model).catch((error) => {
    for (const session of [...sessions.values()]) {
      sendStatus(session, "error", `模型重新加载失败：${error?.message || error}`);
      stopCapture(session.tabId, session.sessionId, false);
    }
  });
}

async function stopCapture(tabId, sessionId, report = false, detail = "本地字幕已停止") {
  const session = sessions.get(tabId);
  if (!session || (sessionId && session.sessionId !== sessionId)) return;
  sessions.delete(tabId);
  session.processor?.disconnect();
  session.sourceNode?.disconnect();
  session.mediaStream?.getTracks().forEach((track) => { track.onended = null; track.stop(); });
  await session.audioContext?.close().catch(() => {});
  session.audioParts = [];
  session.pendingAudio = null;
  // Do not clear an in-flight job here. The worker still owns that pipeline
  // invocation; dispatching another job now would run two WebGPU inference
  // calls concurrently. Its eventual result is discarded, then the queue moves on.
  if (report) sendStatus(session, "stopped", detail);
  if (!sessions.size) {
    asrWorker?.terminate();
    asrWorker = null;
    clearTimeout(jobWatchdog);
    jobWatchdog = null;
    activeJob = null;
    modelState = "idle";
    loadedModel = "";
  } else {
    pumpQueue();
  }
}

function mergeAudio(parts, length) { const result = new Float32Array(length); let offset = 0; for (const part of parts) { result.set(part, offset); offset += part.length; } return result; }
function resample(input, fromRate, toRate) { if (fromRate === toRate) return input; const result = new Float32Array(Math.round(input.length * toRate / fromRate)); const ratio = fromRate / toRate; for (let i = 0; i < result.length; i += 1) { const p = i * ratio; const left = Math.floor(p); const f = p - left; result[i] = input[left] * (1 - f) + (input[Math.min(left + 1, input.length - 1)] || 0) * f; } return result; }
function sendStatus(session, status, detail) { chrome.runtime.sendMessage({ type: "VOICE_STATUS", tabId: session.tabId, sessionId: session.sessionId, status, detail }).catch(() => {}); }
