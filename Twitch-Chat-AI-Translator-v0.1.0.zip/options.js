const form = document.querySelector("#settings-form");
const enabled = document.querySelector("#enabled");
const apiKey = document.querySelector("#api-key");
const targetLanguage = document.querySelector("#target-language");
const hoverDelay = document.querySelector("#hover-delay");
const status = document.querySelector("#status");

loadSettings();

async function loadSettings() {
  const saved = await chrome.storage.local.get({
    enabled: true,
    apiKey: "",
    targetLanguage: "简体中文",
    hoverDelay: 350,
  });
  enabled.checked = saved.enabled;
  apiKey.value = saved.apiKey;
  targetLanguage.value = saved.targetLanguage;
  hoverDelay.value = String(saved.hoverDelay);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  await saveSettings();
  showStatus("设置已保存");
});

document.querySelector("#toggle-key").addEventListener("click", (event) => {
  const reveal = apiKey.type === "password";
  apiKey.type = reveal ? "text" : "password";
  event.currentTarget.textContent = reveal ? "隐藏" : "显示";
});

document.querySelector("#test-api").addEventListener("click", async (event) => {
  event.currentTarget.disabled = true;
  showStatus("正在连接 DeepSeek…");
  try {
    await saveSettings();
    const response = await chrome.runtime.sendMessage({
      type: "TRANSLATE",
      text: "Hello, welcome to the stream!",
      targetLanguage: targetLanguage.value,
    });
    if (!response?.ok) throw new Error(response?.error || "测试失败");
    showStatus(`连接成功：${response.translation}`);
  } catch (error) {
    showStatus(error.message, true);
  } finally {
    event.currentTarget.disabled = false;
  }
});

async function saveSettings() {
  await chrome.storage.local.set({
    enabled: enabled.checked,
    apiKey: apiKey.value.trim(),
    targetLanguage: targetLanguage.value,
    hoverDelay: Number(hoverDelay.value),
  });
}

let statusTimer;
function showStatus(message, isError = false) {
  clearTimeout(statusTimer);
  status.textContent = message;
  status.classList.toggle("error", isError);
  statusTimer = setTimeout(() => { status.textContent = ""; }, 6000);
}
