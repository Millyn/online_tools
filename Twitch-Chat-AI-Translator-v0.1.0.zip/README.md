# Twitch Chat AI Translator

一个使用 DeepSeek API 翻译 Twitch 聊天消息的 Chrome 扩展。鼠标在消息上短暂停留后，译文会显示在原文下方。

## 安装

1. 打开 Chrome，在地址栏输入 `chrome://extensions`。
2. 打开右上角的“开发者模式”。
3. 点击“加载已解压的扩展程序”，选择本项目文件夹。
4. 点击插件图标，进入设置并填写自己的 DeepSeek API Key。
5. 打开或刷新 Twitch 直播页面，将鼠标停留在聊天消息上。

## 数据与缓存

- API Key 和用户设置保存在 Chrome 扩展本地存储中。
- 翻译结果只保存在当前页面的运行内存中，最多 500 条。
- 刷新页面、关闭标签页或切换直播间后，翻译缓存会清空。
- 聊天正文会被发送至 DeepSeek API 以完成翻译。

## 权限

- `storage`：保存 API Key 与插件设置。
- `https://www.twitch.tv/*`：读取聊天消息并显示译文。
- `https://api.deepseek.com/*`：调用 DeepSeek 翻译接口。
