const toggle = document.querySelector("#enabled");
const state = document.querySelector("#state");

chrome.storage.local.get({ enabled: true, apiKey: "" }).then((settings) => {
  toggle.checked = settings.enabled;
  state.textContent = settings.apiKey ? "DeepSeek 已配置" : "需要配置 API Key";
});

toggle.addEventListener("change", async () => {
  await chrome.storage.local.set({ enabled: toggle.checked });
  state.textContent = toggle.checked ? "悬停翻译已启用" : "悬停翻译已暂停";
});

document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
