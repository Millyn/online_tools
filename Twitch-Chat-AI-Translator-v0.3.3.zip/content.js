(() => {
  const MESSAGE_SELECTOR = [
    '[data-a-target="chat-line-message"]',
    '[data-test-selector="chat-line-message"]',
    ".chat-line__message",
  ].join(",");
  const BODY_SELECTORS = [
    '[data-a-target="chat-message-text"]',
    '[data-test-selector="chat-line-message-body"]',
    ".text-fragment",
  ];
  const CACHE_LIMIT = 500;

  let settings = { enabled: true, targetLanguage: "简体中文", hoverDelay: 350, subtitleSize: 22, subtitleOpacity: 0.75, subtitlePosition: null };
  let pageUrl = location.href;
  let hoverTimer = null;
  let activeLine = null;
  let requestSequence = 0;
  const pageCache = new Map();

  initialize();

  async function initialize() {
    settings = { ...settings, ...(await chrome.storage.local.get(settings)) };
    document.addEventListener("pointerover", onPointerOver, true);
    document.addEventListener("pointerout", onPointerOut, true);
    chrome.storage.onChanged.addListener(onSettingsChanged);
    chrome.runtime.onMessage.addListener(onRuntimeMessage);
    setInterval(checkNavigation, 1000);
  }

  function onRuntimeMessage(message, sender, sendResponse) {
    if (message?.type === "TCAT_PING") {
      sendResponse({ twitchPage: true });
      return false;
    }
    if (message?.type !== "SUBTITLE") return;
    let overlay = document.querySelector("#tcat-subtitle-overlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "tcat-subtitle-overlay";
      overlay.innerHTML = '<div class="tcat-subtitle-original"></div><div class="tcat-subtitle-translation"></div>';
      document.body.append(overlay);
      overlay.title = "拖动可移动字幕；双击恢复默认位置";
      enableOverlayDragging(overlay);
      applyOverlaySettings(overlay);
    }
    overlay.classList.toggle("is-error", Boolean(message.error));
    overlay.querySelector(".tcat-subtitle-original").textContent = message.original;
    overlay.querySelector(".tcat-subtitle-translation").textContent = message.translation;
    overlay.classList.add("is-visible");
    clearTimeout(overlay.hideTimer);
    overlay.hideTimer = setTimeout(() => overlay.classList.remove("is-visible"), 9000);
  }

  function onSettingsChanged(changes, area) {
    if (area !== "local") return;
    for (const [key, change] of Object.entries(changes)) settings[key] = change.newValue;
    const overlay = document.querySelector("#tcat-subtitle-overlay");
    if (overlay) applyOverlaySettings(overlay);
  }

  function applyOverlaySettings(overlay) {
    overlay.style.setProperty("--tcat-font-size", `${Number(settings.subtitleSize) || 22}px`);
    overlay.style.setProperty("--tcat-bg-opacity", String(Number(settings.subtitleOpacity) || 0.75));
    const position = settings.subtitlePosition;
    if (position && Number.isFinite(position.left) && Number.isFinite(position.top)) {
      overlay.style.left = `${Math.max(8, Math.min(position.left, innerWidth - 120))}px`;
      overlay.style.top = `${Math.max(8, Math.min(position.top, innerHeight - 60))}px`;
      overlay.style.bottom = "auto";
      overlay.style.transform = "none";
      overlay.dataset.moved = "true";
    } else {
      overlay.style.left = "50%";
      overlay.style.top = "auto";
      overlay.style.bottom = "11vh";
      overlay.style.transform = "translate(-50%, 0)";
      delete overlay.dataset.moved;
    }
  }

  function enableOverlayDragging(overlay) {
    let drag = null;
    overlay.addEventListener("pointerdown", (event) => {
      const rect = overlay.getBoundingClientRect();
      drag = { x: event.clientX - rect.left, y: event.clientY - rect.top };
      overlay.setPointerCapture(event.pointerId);
      overlay.classList.add("is-dragging");
      event.preventDefault();
    });
    overlay.addEventListener("pointermove", (event) => {
      if (!drag) return;
      const left = Math.max(8, Math.min(event.clientX - drag.x, innerWidth - overlay.offsetWidth - 8));
      const top = Math.max(8, Math.min(event.clientY - drag.y, innerHeight - overlay.offsetHeight - 8));
      overlay.style.left = `${left}px`;
      overlay.style.top = `${top}px`;
      overlay.style.bottom = "auto";
      overlay.style.transform = "none";
      overlay.dataset.moved = "true";
      settings.subtitlePosition = { left, top };
    });
    overlay.addEventListener("pointerup", (event) => {
      if (!drag) return;
      drag = null;
      overlay.releasePointerCapture(event.pointerId);
      overlay.classList.remove("is-dragging");
      chrome.storage.local.set({ subtitlePosition: settings.subtitlePosition });
    });
    overlay.addEventListener("dblclick", () => {
      settings.subtitlePosition = null;
      chrome.storage.local.remove("subtitlePosition");
      applyOverlaySettings(overlay);
    });
  }

  function checkNavigation() {
    if (location.href === pageUrl) return;
    pageUrl = location.href;
    clearPageState();
  }

  function clearPageState() {
    pageCache.clear();
    clearTimeout(hoverTimer);
    activeLine = null;
    requestSequence += 1;
    document.querySelectorAll(".tcat-translation").forEach((node) => node.remove());
  }

  function onPointerOver(event) {
    if (!settings.enabled) return;
    const line = event.target.closest?.(MESSAGE_SELECTOR);
    if (!line || line === activeLine || line.contains(event.relatedTarget)) return;

    clearTimeout(hoverTimer);
    activeLine = line;
    const sequence = ++requestSequence;
    const delay = clamp(Number(settings.hoverDelay) || 350, 100, 1500);
    hoverTimer = setTimeout(() => translateLine(line, sequence), delay);
  }

  function onPointerOut(event) {
    const line = event.target.closest?.(MESSAGE_SELECTOR);
    if (!line || line.contains(event.relatedTarget)) return;
    if (line === activeLine) {
      clearTimeout(hoverTimer);
      activeLine = null;
      requestSequence += 1;
    }
  }

  async function translateLine(line, sequence) {
    if (!line.isConnected || line !== activeLine) return;
    const text = extractMessageText(line);
    if (!shouldTranslate(text)) return;

    const existing = line.querySelector(":scope > .tcat-translation");
    if (existing?.dataset.state === "done") return;

    if (pageCache.has(text)) {
      renderTranslation(line, pageCache.get(text), "done");
      return;
    }

    renderTranslation(line, "正在翻译…", "loading");
    let response;
    try {
      response = await chrome.runtime.sendMessage({
        type: "TRANSLATE",
        text,
        targetLanguage: settings.targetLanguage,
      });
    } catch (error) {
      response = { ok: false, error: error.message || "插件后台连接失败" };
    }

    if (!line.isConnected) return;
    if (!response?.ok) {
      renderTranslation(line, response?.error || "翻译失败", "error");
      return;
    }

    remember(text, response.translation);
    renderTranslation(line, response.translation, "done");
  }

  function extractMessageText(line) {
    const fragments = [...line.querySelectorAll(BODY_SELECTORS.join(","))];
    if (fragments.length) {
      const leafFragments = fragments.filter(
        (node) => !fragments.some((other) => other !== node && node.contains(other)),
      );
      const text = leafFragments.map(readNodeText).join(" ");
      if (text.trim()) return normalize(text);
    }

    const clone = line.cloneNode(true);
    clone.querySelectorAll(
      ".tcat-translation, [data-a-target*=badge], [data-a-target*=username], .chat-author__display-name",
    ).forEach((node) => node.remove());
    return normalize(readNodeText(clone));
  }

  function readNodeText(node) {
    const clone = node.cloneNode(true);
    clone.querySelectorAll("img[alt]").forEach((image) => image.replaceWith(` ${image.alt} `));
    return clone.textContent || "";
  }

  function normalize(text) {
    return text.replace(/\s+/g, " ").trim().slice(0, 2000);
  }

  function shouldTranslate(text) {
    if (!text || text.length < 2) return false;
    if (/^https?:\/\/\S+$/i.test(text)) return false;
    if (!/[\p{L}\p{N}]/u.test(text)) return false;
    if (settings.targetLanguage === "简体中文") {
      const letters = [...text].filter((char) => /\p{L}/u.test(char));
      const chinese = letters.filter((char) => /\p{Script=Han}/u.test(char));
      if (letters.length && chinese.length / letters.length > 0.7) return false;
    }
    return true;
  }

  function renderTranslation(line, text, state) {
    let output = line.querySelector(":scope > .tcat-translation");
    if (!output) {
      output = document.createElement("div");
      output.className = "tcat-translation";
      line.append(output);
    }
    output.dataset.state = state;
    output.textContent = text;
    output.title = state === "error" ? "再次悬停可重试" : "DeepSeek 翻译";
  }

  function remember(key, value) {
    pageCache.set(key, value);
    if (pageCache.size > CACHE_LIMIT) pageCache.delete(pageCache.keys().next().value);
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }
})();
