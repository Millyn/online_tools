const toggle = document.querySelector("#enabled");
const state = document.querySelector("#state");
const voiceButton = document.querySelector("#voice");
let voiceRunning = false;

chrome.storage.local.get({ enabled: true, apiKey: "" }).then((settings) => {
  toggle.checked = settings.enabled;
  state.textContent = settings.apiKey ? "DeepSeek 已配置" : "需要配置 API Key";
});

chrome.runtime.sendMessage({ type: "GET_VOICE_STATUS" }).then((saved) => {
  const running = saved?.voiceStatus === "running" || saved?.voiceStatus === "starting";
  setVoiceState(running, saved?.voiceDetail || "本地字幕未启动");
});

toggle.addEventListener("change", async () => {
  await chrome.storage.local.set({ enabled: toggle.checked });
  state.textContent = toggle.checked ? "悬停翻译已启用" : "悬停翻译已暂停";
});

document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());

voiceButton.addEventListener("click", async () => {
  voiceButton.disabled = true;
  try {
    if (voiceRunning) {
      await chrome.runtime.sendMessage({ type: "STOP_VOICE" });
      setVoiceState(false, "本地字幕已停止");
      return;
    }
    const settings = await chrome.storage.local.get({ apiKey: "", localModelReady: false });
    if (!settings.localModelReady) throw new Error("请先在设置中下载本地模型");
    if (!settings.apiKey) throw new Error("请先在设置中填写 DeepSeek API Key");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("无法取得当前标签页");
    const pageUrl = tab.url || tab.pendingUrl || "";
    let isTwitchPage = pageUrl.startsWith("https://www.twitch.tv/");
    if (!isTwitchPage) {
      try {
        const page = await chrome.tabs.sendMessage(tab.id, { type: "TCAT_PING" });
        isTwitchPage = page?.twitchPage === true;
      } catch {}
    }
    if (!isTwitchPage) throw new Error("请先打开或刷新 Twitch 直播页面");
    const captured = await chrome.tabCapture.getCapturedTabs();
    if (captured.some((item) => item.tabId === tab.id && item.status !== "stopped")) {
      await chrome.runtime.sendMessage({ type: "STOP_VOICE" });
      await new Promise((resolve) => setTimeout(resolve, 250));
      const remaining = await chrome.tabCapture.getCapturedTabs();
      if (remaining.some((item) => item.tabId === tab.id && item.status !== "stopped")) {
        throw new Error("该页面仍被字幕程序占用，请刷新 Twitch 页面后重试");
      }
    }
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    const response = await chrome.runtime.sendMessage({ type: "START_VOICE", streamId, tabId: tab.id });
    if (!response?.ok) throw new Error(response?.error || "启动失败");
    setVoiceState(true, "正在加载本地模型…");
  } catch (error) {
    state.textContent = String(error.message || error).includes("active stream")
      ? "该页面已被其他版本占用，请停用旧版插件并刷新 Twitch 页面"
      : error.message;
  } finally {
    voiceButton.disabled = false;
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "VOICE_STATUS_BROADCAST") return;
  state.textContent = message.detail;
  if (message.status === "running") setVoiceState(true, message.detail);
  if (message.status === "stopped" || message.status === "error") setVoiceState(false, message.detail);
});

function setVoiceState(running, detail) {
  voiceRunning = running;
  voiceButton.textContent = running ? "停止本地语音字幕" : "开始本地语音字幕";
  state.textContent = detail;
}
