let mediaStream = null;
let audioContext = null;
let processor = null;
let sourceNode = null;
let asrWorker = null;
let audioParts = [];
let sampleCount = 0;
let sourceTabId = null;
let workerBusy = false;
let pendingAudio = null;

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "OFFSCREEN_START") startCapture(message.streamId, message.tabId);
  if (message?.type === "OFFSCREEN_STOP") stopCapture();
});

async function startCapture(streamId, tabId) {
  stopCapture();
  sourceTabId = tabId;
  sendStatus("starting", "正在加载本地语音模型…");
  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } },
      video: false,
    });
    audioContext = new AudioContext();
    sourceNode = audioContext.createMediaStreamSource(mediaStream);
    sourceNode.connect(audioContext.destination);
    processor = audioContext.createScriptProcessor(4096, 1, 1);
    sourceNode.connect(processor);
    processor.connect(audioContext.destination);
    processor.onaudioprocess = collectAudio;

    asrWorker = new Worker(chrome.runtime.getURL("assets/asr-worker.js"), { type: "module" });
    asrWorker.onmessage = onWorkerMessage;
    asrWorker.onerror = (event) => sendStatus("error", `模型运行失败：${event.message}`);
    asrWorker.postMessage({ type: "LOAD_MODEL", wasmBase: chrome.runtime.getURL("assets/") });
  } catch (error) {
    stopCapture();
    sendStatus("error", error.message || "无法获取标签页音频");
  }
}

function collectAudio(event) {
  const data = new Float32Array(event.inputBuffer.getChannelData(0));
  audioParts.push(data);
  sampleCount += data.length;
  if (sampleCount < audioContext.sampleRate * 4) return;
  const merged = mergeAudio(audioParts, sampleCount);
  audioParts = [];
  sampleCount = 0;
  const rms = Math.sqrt(merged.reduce((sum, value) => sum + value * value, 0) / merged.length);
  if (rms < 0.008) return;
  const downsampled = resample(merged, audioContext.sampleRate, 16000);
  if (workerBusy) pendingAudio = downsampled;
  else transcribe(downsampled);
}

function transcribe(audio) {
  if (!asrWorker) return;
  workerBusy = true;
  asrWorker.postMessage({ type: "TRANSCRIBE", audio }, [audio.buffer]);
}

function onWorkerMessage(event) {
  const message = event.data;
  if (message.type === "READY") sendStatus("running", "本地字幕运行中");
  if (message.type === "ERROR") sendStatus("error", message.error);
  if (message.type === "RESULT" && message.text) {
    chrome.runtime.sendMessage({ type: "ASR_TEXT", text: message.text, tabId: sourceTabId });
  }
  if (message.type === "RESULT" || message.type === "ERROR") {
    workerBusy = false;
    if (pendingAudio) {
      const next = pendingAudio;
      pendingAudio = null;
      transcribe(next);
    }
  }
}

function stopCapture() {
  if (processor) processor.disconnect();
  if (sourceNode) sourceNode.disconnect();
  if (mediaStream) mediaStream.getTracks().forEach((track) => track.stop());
  if (audioContext) audioContext.close().catch(() => {});
  if (asrWorker) asrWorker.terminate();
  mediaStream = audioContext = processor = sourceNode = asrWorker = null;
  audioParts = [];
  sampleCount = 0;
  workerBusy = false;
  pendingAudio = null;
  sendStatus("stopped", "本地字幕已停止");
}

function mergeAudio(parts, length) {
  const result = new Float32Array(length);
  let offset = 0;
  for (const part of parts) { result.set(part, offset); offset += part.length; }
  return result;
}

function resample(input, fromRate, toRate) {
  if (fromRate === toRate) return input;
  const result = new Float32Array(Math.round(input.length * toRate / fromRate));
  const ratio = fromRate / toRate;
  for (let index = 0; index < result.length; index += 1) {
    const position = index * ratio;
    const left = Math.floor(position);
    const fraction = position - left;
    result[index] = input[left] * (1 - fraction) + (input[Math.min(left + 1, input.length - 1)] || 0) * fraction;
  }
  return result;
}

function sendStatus(status, detail) {
  chrome.runtime.sendMessage({ type: "VOICE_STATUS", status, detail }).catch(() => {});
}
