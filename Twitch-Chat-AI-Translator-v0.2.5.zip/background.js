const DEFAULT_SETTINGS = {
  enabled: true,
  apiKey: "",
  targetLanguage: "简体中文",
  hoverDelay: 350,
};

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  const missing = Object.fromEntries(
    Object.entries(DEFAULT_SETTINGS).filter(([key]) => current[key] === undefined),
  );
  if (Object.keys(missing).length) await chrome.storage.local.set(missing);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "START_VOICE") {
    startVoice(message.streamId, message.tabId)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "STOP_VOICE") {
    chrome.runtime.sendMessage({ type: "OFFSCREEN_STOP" }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === "GET_VOICE_STATUS") {
    chrome.storage.session.get({ voiceStatus: "stopped", voiceDetail: "本地字幕未启动" })
      .then(sendResponse);
    return true;
  }
  if (message?.type === "ASR_TEXT") {
    handleAsrText(message.text, message.tabId);
    return false;
  }
  if (message?.type === "VOICE_STATUS") {
    chrome.storage.session.set({ voiceStatus: message.status, voiceDetail: message.detail });
    chrome.runtime.sendMessage({ ...message, type: "VOICE_STATUS_BROADCAST" }).catch(() => {});
    return false;
  }
  if (message?.type !== "TRANSLATE") return false;

  translateMessage(message.text, message.targetLanguage, message.context)
    .then((translation) => sendResponse({ ok: true, translation }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

async function translateMessage(text, requestedLanguage, context = "chat") {
  const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const apiKey = String(settings.apiKey || "").trim();
  const targetLanguage = requestedLanguage || settings.targetLanguage;

  if (!apiKey) throw new Error("请先在插件设置中填写 DeepSeek API Key");
  if (!text || typeof text !== "string") throw new Error("没有可翻译的文字");

  const response = await fetch("https://api.deepseek.com/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "deepseek-chat",
      messages: [
        {
          role: "system",
          content:
            `你是 Twitch ${context === "voice" ? "直播字幕" : "直播聊天"}翻译器。把用户消息翻译为${targetLanguage}。` +
            "保留用户名、游戏专有名词、表情符号、网络梗和原有语气。" +
            "只输出译文，不解释，不加引号。如果不需要翻译，原样输出。",
        },
        { role: "user", content: text.slice(0, 2000) },
      ],
      temperature: 0.2,
      max_tokens: 500,
      stream: false,
    }),
  });

  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error(`DeepSeek 返回了无法解析的响应（HTTP ${response.status}）`);
  }

  if (!response.ok) {
    const detail = data?.error?.message || `HTTP ${response.status}`;
    throw new Error(`DeepSeek 请求失败：${detail}`);
  }

  const translation = data?.choices?.[0]?.message?.content?.trim();
  if (!translation) throw new Error("DeepSeek 没有返回译文");
  return translation;
}

async function startVoice(streamId, tabId) {
  if (!streamId || !tabId) throw new Error("没有取得 Twitch 标签页音频");
  const offscreenUrl = chrome.runtime.getURL("offscreen.html");
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [offscreenUrl],
  });
  if (!contexts.length) {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["USER_MEDIA"],
      justification: "Capture Twitch tab audio for local speech recognition",
    });
  }
  await chrome.runtime.sendMessage({ type: "OFFSCREEN_START", streamId, tabId });
}

async function handleAsrText(text, tabId) {
  const clean = String(text || "").trim();
  if (!clean) return;
  chrome.tabs.sendMessage(tabId, { type: "SUBTITLE", original: clean, translation: "翻译中…" }).catch(() => {});
  try {
    const translation = await translateMessage(clean, null, "voice");
    await chrome.tabs.sendMessage(tabId, { type: "SUBTITLE", original: clean, translation });
  } catch (error) {
    await chrome.tabs.sendMessage(tabId, {
      type: "SUBTITLE",
      original: clean,
      translation: `翻译失败：${error.message}`,
      error: true,
    }).catch(() => {});
  }
}
